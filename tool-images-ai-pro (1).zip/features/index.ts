/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export { IdPhotoApp } from './idPhoto/IdPhotoApp';
export { RestorationApp } from './restoration/RestorationApp';
export { DocumentRestorationApp } from './documentRestoration/DocumentRestorationApp';
export { FashionDesignApp } from './fashionDesign/FashionDesignApp';
export { ClothingChangeApp } from './clothingChange/ClothingChangeApp';
export { FacialSymmetryEditor } from './symmetry/FacialSymmetryEditor';
export { LightingEditor } from './lighting/LightingEditor';
// FIX: Corrected export for BackgroundApp.
export { BackgroundApp } from './background/BackgroundApp';
export { MockupApp } from './mockup/MockupApp';
export { TrendCreatorApp } from './trendCreator/TrendCreatorApp';
export { SettingsApp } from './settings/SettingsApp';
export { PresetColorApp } from './preset/PresetColorApp';
export { ColorCorrectionApp } from './colorCorrection/ColorCorrectionApp';
export { UpscalerApp } from './upscaler/UpscalerApp';
export { FaceAlignApp } from './faceAlign/FaceAlignApp';
export { FaceTransformApp } from './faceTransform/FaceTransformApp';
export { WrinkleEditorApp } from './wrinkleEditor/WrinkleEditorApp';
export { HistoryApp } from './history/HistoryApp';
export { LoginComponent } from './auth/LoginComponent';