/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { h, FunctionalComponent } from 'preact';
import { useState } from 'preact/hooks';
import htm from 'htm';
import type { TargetedEvent } from 'preact/compat';

import { FaceTransformSettings } from '../../types';
// FIX: Replaced non-existent `HighQualityDownloadButton` with `EnhancedDownloadButton`.
import { Loader, ImageUploader, ImageIcon, EnhancedDownloadButton, DiamondIcon } from '../../components';
import { callGeminiAPI } from '../../api';
import { addHistoryItem } from '../../history';
import { TABS } from '../../constants';

const html = htm.bind(h);

const faceTransformOptions = {
    style: {
        title: "Bước 2: Thêm phong cách",
        description: "Gợi ý phong cách",
        placeholder: "VD: Một hiệp sĩ mặc áo giáp sáng bóng...",
        options: [
            'Tranh kỹ thuật số, giả tưởng', 'Thành phố cyberpunk đèn neon',
            'Chiến binh cổ đại, áo giáp chi tiết', 'Phi hành gia trong không gian, nằn vô trụ',
            'Chân dung phong cách ấn tượng', 'Minh họa màu nước rực rỡ',
            'Gothic và bí ẩn', 'Nhà phát minh Steampunk',
            'Siêu anh hùng, ánh sáng điện ảnh', 'Phong cách nhân vật Anime',
            'Kiệt tác sơn dầu', 'Nhân vật hoạt hình Pixar'
        ],
    },
    context: {
        title: "Bước 3: Xác định bối cảnh",
        description: "Gợi ý bối cảnh",
        placeholder: "VD: Bên trong buồng lái tàu vũ trụ...",
        options: [
            'Rừng sương mù', 'Cảnh quan thành phố tương lai',
            'Lâu đài bị phù phép', 'Bãi biển ngập nắng',
            'Tàn tích hậu tận thế', 'Thư viện ấm cúng',
            'Cảnh quan hành tinh xa lạ', 'Họa tiết hình học trừu tượng'
        ],
    },
    cameraAngle: {
        title: "Bước 4: Đặt góc máy",
        description: "Gợi ý góc máy",
        placeholder: "VD: Chụp từ dưới lên...",
        options: [
            'Cận cảnh', 'Toàn thân', 'Góc nhìn từ dưới lên',
            'Góc nhìn từ trên xuống', 'Góc nghiêng', 'Cảnh rộng',
            'Nhìn nghiêng', 'Góc máy qua vai'
        ],
    },
    lighting: {
        title: "Bước 5: Chọn ánh sáng",
        description: "Gợi ý ánh sáng",
        placeholder: "VD: Ánh nắng chiều tà...",
        options: [
            'Ánh sáng điện ảnh', 'Ánh sáng dịu, khuếch tán',
            'Đèn neon rực rỡ ấn tượng', 'Ánh nắng giờ vàng',
            'Ánh sáng neon', 'Ánh sáng studio',
            'Ánh trăng kỳ bí', 'Ánh sáng khói'
        ],
    }
};

interface ControlStepCardProps {
    title: string;
    description: string;
    options: string[];
    selectedOptions: string[];
    onOptionClick: (option: string) => void;
    customValue: string;
    onCustomChange: (value: string) => void;
    placeholder: string;
}

const ControlStepCard: FunctionalComponent<ControlStepCardProps> = ({ title, description, options, selectedOptions, onOptionClick, customValue, onCustomChange, placeholder }) => {
    return html`
        <div class="control-step-card">
            <h3 class="form-section-title">${title}</h3>
            <div>
                <label class="form-section-label">${description}</label>
                <div class="control-step-options">
                    ${options.map(opt => html`
                        <button 
                            class="option-btn ${selectedOptions.includes(opt) ? 'active' : ''}"
                            onClick=${() => onOptionClick(opt)}
                        >
                            ${opt}
                        </button>
                    `)}
                </div>
            </div>
            <div>
                <label class="form-section-label">Hoặc tự thêm</label>
                <textarea
                    placeholder=${placeholder}
                    value=${customValue}
                    onInput=${(e: TargetedEvent<HTMLTextAreaElement>) => onCustomChange(e.currentTarget.value)}
                />
            </div>
        </div>
    `;
};

export const FaceTransformApp: FunctionalComponent = () => {
    const [uploadedImage, setUploadedImage] = useState<string | null>(null);
    const [generatedImage, setGeneratedImage] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');
    const [settings, setSettings] = useState<FaceTransformSettings>({
        style: [], customStyle: '',
        context: [], customContext: '',
        cameraAngle: [], customCameraAngle: '',
        lighting: [], customLighting: '',
        aspectRatio: '1:1',
    });

    const handleOptionClick = (category: keyof FaceTransformSettings, option: string) => {
        setSettings(prev => {
            const currentSelection = prev[category] as string[];
            const newSelection = currentSelection.includes(option)
                ? currentSelection.filter(item => item !== option)
                : [...currentSelection, option];
            return { ...prev, [category]: newSelection };
        });
    };

    const handleCustomChange = (category: keyof FaceTransformSettings, value: string) => {
        setSettings(prev => ({ ...prev, [category]: value }));
    };

    const handleGenerate = async () => {
        if (!uploadedImage) {
            setError("Vui lòng tải lên ảnh chân dung trước.");
            return;
        }
        setIsLoading(true);
        setError('');
        setGeneratedImage(null);

        const { style, customStyle, context, customContext, cameraAngle, customCameraAngle, lighting, customLighting, aspectRatio } = settings;

        const promptParts = [
            "Generate a photorealistic, high-detail image.",
            "CRITICAL: The main subject's face, identity, and core features must be an EXACT match to the person in the provided reference photo."
        ];

        if (aspectRatio) {
            promptParts.push(`The final image must have a ${aspectRatio} aspect ratio.`);
        }

        const styleText = [...style, customStyle].filter(Boolean).join(', ');
        if (styleText) promptParts.push(`The artistic style is: ${styleText}.`);

        const contextText = [...context, customContext].filter(Boolean).join(', ');
        if (contextText) promptParts.push(`The setting and background is: ${contextText}.`);
        
        const cameraAngleText = [...cameraAngle, customCameraAngle].filter(Boolean).join(', ');
        if (cameraAngleText) promptParts.push(`The camera shot is a ${cameraAngleText}.`);

        const lightingText = [...lighting, customLighting].filter(Boolean).join(', ');
        if (lightingText) promptParts.push(`The scene is lit with ${lightingText}.`);

        const finalPrompt = promptParts.join(' ');
        
        try {
            const result = await callGeminiAPI(finalPrompt, uploadedImage);
            setGeneratedImage(result);
            const featureInfo = TABS.find(t => t.id === 'face-transform');
            await addHistoryItem({
                original: uploadedImage,
                generated: result,
                feature: 'face-transform',
                featureLabel: featureInfo?.label || 'AI Hoán Đổi Gương Mặt',
            });
        } catch (err) {
            setError(err instanceof Error ? err.message : "Đã xảy ra lỗi không xác định.");
        } finally {
            setIsLoading(false);
        }
    };

    const aspectRatioOptions = [
        { label: 'Vuông (1:1)', value: '1:1' },
        { label: 'Màn ảnh rộng (16:9)', value: '16:9' },
        { label: 'Chân dung (9:16)', value: '9:16' },
        { label: 'Phong cảnh (4:3)', value: '4:3' },
        { label: 'Cao (3:4)', value: '3:4' },
    ];

    return html`
        <div class="page-header" style=${{textAlign: 'center', maxWidth: '800px', margin: '0 auto 2rem auto'}}>
            <h1>AI Hoán Đổi Gương Mặt</h1>
            <p class="subtitle">Tạo ra những hình ảnh mới tuyệt đẹp bằng cách kết hợp khuôn mặt của bạn với các ý tưởng sáng tạo.</p>
        </div>
        <div class="face-transform-layout">
            <div class="face-transform-controls">
                <${ControlStepCard}
                    title=${faceTransformOptions.style.title}
                    description=${faceTransformOptions.style.description}
                    options=${faceTransformOptions.style.options}
                    selectedOptions=${settings.style}
                    onOptionClick=${(opt: string) => handleOptionClick('style', opt)}
                    customValue=${settings.customStyle}
                    onCustomChange=${(val: string) => handleCustomChange('customStyle', val)}
                    placeholder=${faceTransformOptions.style.placeholder}
                />
                <${ControlStepCard}
                    title=${faceTransformOptions.context.title}
                    description=${faceTransformOptions.context.description}
                    options=${faceTransformOptions.context.options}
                    selectedOptions=${settings.context}
                    onOptionClick=${(opt: string) => handleOptionClick('context', opt)}
                    customValue=${settings.customContext}
                    onCustomChange=${(val: string) => handleCustomChange('customContext', val)}
                    placeholder=${faceTransformOptions.context.placeholder}
                />
                <${ControlStepCard}
                    title=${faceTransformOptions.cameraAngle.title}
                    description=${faceTransformOptions.cameraAngle.description}
                    options=${faceTransformOptions.cameraAngle.options}
                    selectedOptions=${settings.cameraAngle}
                    onOptionClick=${(opt: string) => handleOptionClick('cameraAngle', opt)}
                    customValue=${settings.customCameraAngle}
                    onCustomChange=${(val: string) => handleCustomChange('customCameraAngle', val)}
                    placeholder=${faceTransformOptions.cameraAngle.placeholder}
                />
                <${ControlStepCard}
                    title=${faceTransformOptions.lighting.title}
                    description=${faceTransformOptions.lighting.description}
                    options=${faceTransformOptions.lighting.options}
                    selectedOptions=${settings.lighting}
                    onOptionClick=${(opt: string) => handleOptionClick('lighting', opt)}
                    customValue=${settings.customLighting}
                    onCustomChange=${(val: string) => handleCustomChange('customLighting', val)}
                    placeholder=${faceTransformOptions.lighting.placeholder}
                />
                 <div class="control-step-card" style="grid-column: 1 / -1;">
                    <h3 class="form-section-title">Bước 6: Chọn tỷ lệ</h3>
                    <div class="aspect-ratio-options">
                        ${aspectRatioOptions.map(opt => html`
                            <button
                                class="option-btn ${settings.aspectRatio === opt.value ? 'active' : ''}"
                                onClick=${() => setSettings(s => ({ ...s, aspectRatio: opt.value }))}
                            >
                                ${opt.label}
                            </button>
                        `)}
                    </div>
                </div>
            </div>
            <div class="face-transform-io">
                <div class="control-step-card">
                    <h3 class="form-section-title">Bước 1: Tải lên ảnh chân dung</h3>
                    ${uploadedImage ? html`
                        <div class="image-preview-container">
                            <img src=${uploadedImage} alt="Uploaded portrait" />
                             <button class="btn btn-secondary" onClick=${() => setUploadedImage(null)} style=${{width: '100%', marginTop:'1rem'}}>
                                Tải ảnh khác
                            </button>
                        </div>
                    ` : html`
                         <${ImageUploader} onImageUpload=${setUploadedImage} />
                    `}
                </div>
                <div class="generation-box">
                    <h4>Sẵn sàng sáng tạo?</h4>
                    <button class="btn btn-primary" onClick=${handleGenerate} disabled=${isLoading || !uploadedImage}>
                        ${isLoading ? 'Đang tạo...' : 'Kết hợp hình ảnh'}
                    </button>
                </div>
                <div class="face-transform-result-panel">
                    ${isLoading && html`<${Loader} text="AI đang sáng tạo..." />`}
                    ${!generatedImage && !isLoading && html`
                        <div class="placeholder-container">
                            <${ImageIcon} class="placeholder-icon"/>
                            <p class="placeholder-text">Tuyệt tác của bạn sẽ xuất hiện ở đây.</p>
                        </div>
                    `}
                    ${generatedImage && html`<img src=${generatedImage} alt="Generated result" />`}
                </div>
                ${error && html`<div class="error-message">${error}</div>`}
                ${generatedImage && html`
                    <${EnhancedDownloadButton} baseImageUrl=${generatedImage} filename="face-transform-result-8k.jpeg" style=${{width: '100%'}}>
                        <${DiamondIcon} /> Tải 8K Sắc Nét
                    </${EnhancedDownloadButton}>
                `}
            </div>
        </div>
    `;
};