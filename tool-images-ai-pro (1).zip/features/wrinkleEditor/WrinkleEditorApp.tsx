/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { h, FunctionalComponent } from 'preact';
import { useState, useEffect } from 'preact/hooks';
import htm from 'htm';

import { WrinkleEditorSettings } from '../../types';
// FIX: Replaced non-existent `HighQualityDownloadButton` with `EnhancedDownloadButton`.
import { Loader, ImageUploader, ImageComparisonSlider, EnhancedDownloadButton, DiamondIcon } from '../../components';
import { removeWrinkles } from '../../api';
import { addHistoryItem } from '../../history';
import { TABS } from '../../constants';

const html = htm.bind(h);

export const WrinkleEditorApp: FunctionalComponent = () => {
    const [settings, setSettings] = useState<WrinkleEditorSettings>({
        targetArea: 'face',
        processMode: 'single',
    });
    const [originalImage, setOriginalImage] = useState<string | null>(null);
    const [generatedImage, setGeneratedImage] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');

    useEffect(() => {
        if (originalImage && settings.processMode === 'single') {
            handleGenerate();
        }
    }, [originalImage, settings.targetArea]);

    const handleImageUpload = (dataUrl: string | null) => {
        setOriginalImage(dataUrl);
        setGeneratedImage(null);
        setError('');
    };
    
    const handleGenerate = async () => {
        if (!originalImage) return;

        setIsLoading(true);
        setError('');
        try {
            const result = await removeWrinkles(originalImage, settings);
            setGeneratedImage(result);
            const featureInfo = TABS.find(t => t.id === 'wrinkle-editor');
            await addHistoryItem({
                original: originalImage,
                generated: result,
                feature: 'wrinkle-editor',
                featureLabel: featureInfo?.label || 'Chỉnh sửa nếp nhăn AI',
            });
        } catch (err) {
            setError(err instanceof Error ? err.message : "An unknown error occurred.");
        } finally {
            setIsLoading(false);
        }
    };

    return html`
        <div class="wrinkle-editor-container">
            <h1>Chỉnh sửa nếp nhăn AI</h1>
            <p class="subtitle">Tải ảnh lên và để AI làm mờ nếp nhăn trên mặt hoặc quần áo.</p>
            
            <div class="form-group">
                <label class="form-section-label">Bạn muốn xóa nếp nhăn ở đâu?</label>
                 <div class="pill-toggle-group">
                    <button 
                        class="pill-toggle-btn ${settings.targetArea === 'face' ? 'active' : ''}"
                        onClick=${() => setSettings(s => ({...s, targetArea: 'face'}))}
                    >Trên mặt</button>
                    <button 
                        class="pill-toggle-btn ${settings.targetArea === 'clothes' ? 'active' : ''}"
                        onClick=${() => setSettings(s => ({...s, targetArea: 'clothes'}))}
                    >Trên quần áo</button>
                </div>
            </div>

             <div class="form-group">
                <div class="pill-toggle-group secondary">
                    <button 
                        class="pill-toggle-btn ${settings.processMode === 'single' ? 'active' : ''}"
                        onClick=${() => setSettings(s => ({...s, processMode: 'single'}))}
                    >Một ảnh</button>
                    <button 
                        class="pill-toggle-btn ${settings.processMode === 'batch' ? 'active' : ''}"
                        onClick=${() => { alert('Xử lý hàng loạt sắp ra mắt!'); }}
                    >Xử lý hàng loạt</button>
                </div>
            </div>

            <div class="wrinkle-upload-area">
                ${!originalImage ? html`
                    <${ImageUploader} 
                        onImageUpload=${(img: string) => handleImageUpload(img)} 
                        id="wrinkle-uploader" 
                    />
                ` : html`
                    <div class="image-panel-preview">
                        ${isLoading && html`<${Loader} text="AI đang xử lý nếp nhăn..." />`}
                        <div class="image-display-wrapper">
                            <${ImageComparisonSlider} original=${originalImage} generated=${generatedImage} objectFit="contain" />
                        </div>
                        ${error && html`<div class="error-message">${error}</div>`}
                        <div class="actions" style=${{width: '100%', marginTop: '1.5rem'}}>
                            <button class="btn btn-secondary" onClick=${() => handleImageUpload(null)}>Tải ảnh khác</button>
                            <${EnhancedDownloadButton} baseImageUrl=${generatedImage} filename="wrinkle-free-8k.jpeg">
                                <${DiamondIcon} /> Tải 8K Sắc Nét
                            </${EnhancedDownloadButton}>
                        </div>
                    </div>
                `}
            </div>
        </div>
    `;
};