/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { h, FunctionalComponent } from 'preact';
import { useState, useEffect } from 'preact/hooks';
import htm from 'htm';
import { HistoryItem } from '../../types';
import { loadHistory, deleteHistoryItem, clearHistory } from '../../history';
// FIX: Replaced non-existent `HighQualityDownloadButton` with `EnhancedDownloadButton`.
import { ImageComparisonSlider, CloseIcon, DeleteIcon, EnhancedDownloadButton, DiamondIcon } from '../../components';

const html = htm.bind(h);

interface HistoryLightboxProps {
    item: HistoryItem;
    onClose: () => void;
}

const HistoryLightbox: FunctionalComponent<HistoryLightboxProps> = ({ item, onClose }) => {
    return html`
        <div class="lightbox-overlay" onClick=${onClose}>
            <div class="lightbox-content" onClick=${(e: MouseEvent) => e.stopPropagation()} style=${{ width: '90vw', height: '90vh', maxWidth: '1600px' }}>
                <div class="lightbox-header">
                    <h3>So sánh - ${item.featureLabel}</h3>
                    <div class="lightbox-actions">
                         <${EnhancedDownloadButton} baseImageUrl=${item.generated} filename=${`${item.feature}-${item.id}-8k.jpeg`}>
                            <${DiamondIcon} /> Tải 8K Sắc Nét
                        </${EnhancedDownloadButton}>
                        <button class="lightbox-close-btn" onClick=${onClose} title="Close">
                            <${CloseIcon} />
                        </button>
                    </div>
                </div>
                <div class="lightbox-image-wrapper-single">
                    <${ImageComparisonSlider} original=${item.original} generated=${item.generated} objectFit="contain" />
                </div>
            </div>
        </div>
    `;
};

export const HistoryApp: FunctionalComponent = () => {
    const [history, setHistory] = useState<HistoryItem[]>([]);
    const [selectedItem, setSelectedItem] = useState<HistoryItem | null>(null);

    useEffect(() => {
        setHistory(loadHistory());
    }, []);

    const handleDelete = (e: MouseEvent, id: number) => {
        e.stopPropagation();
        deleteHistoryItem(id);
        setHistory(h => h.filter(item => item.id !== id));
    };

    const handleClearAll = () => {
        if (window.confirm('Bạn có chắc chắn muốn xóa toàn bộ lịch sử không? Hành động này không thể hoàn tác.')) {
            clearHistory();
            setHistory([]);
        }
    };

    const formatDate = (timestamp: number) => {
        return new Date(timestamp).toLocaleString('vi-VN', {
            hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit', year: 'numeric'
        });
    };

    return html`
        ${selectedItem && html`<${HistoryLightbox} item=${selectedItem} onClose=${() => setSelectedItem(null)} />`}
        <div class="history-app-container">
            <div class="history-header">
                <h1>Lịch sử chỉnh sửa</h1>
                ${history.length > 0 && html`
                    <button class="btn btn-danger" onClick=${handleClearAll}>
                        <${DeleteIcon} /> Xóa tất cả
                    </button>
                `}
            </div>
            
            ${history.length === 0 ? html`
                <div class="history-empty-state">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M13 3c-4.97 0-9 4.03-9 9H1l3.89 3.89.07.14L9 12H6c0-3.87 3.13-7 7-7s7 3.13 7 7-3.13 7-7 7c-1.93 0-3.68-.79-4.94-2.06l-1.42 1.42C8.27 19.99 10.51 21 13 21c4.97 0 9-4.03 9-9s-4.03-9-9-9zm-1 5v5l4.25 2.52.75-1.23-3.5-2.07V8H12z"/></svg>
                    <h3>Lịch sử trống</h3>
                    <p>Bắt đầu chỉnh sửa để xem kết quả của bạn ở đây.</p>
                </div>
            ` : html`
                <div class="history-grid">
                    ${history.map(item => html`
                        <div class="history-card" key=${item.id} onClick=${() => setSelectedItem(item)}>
                            <img src=${item.generated} alt="Generated image" />
                            <div class="history-card-overlay">
                                <div class="history-card-feature">${item.featureLabel}</div>
                                <div class="history-card-date">${formatDate(item.timestamp)}</div>
                            </div>
                             <button class="history-card-delete-btn" onClick=${(e: MouseEvent) => handleDelete(e, item.id)}>
                                <${DeleteIcon} />
                            </button>
                        </div>
                    `)}
                </div>
            `}
        </div>
    `;
};