/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { h, FunctionalComponent } from 'preact';
import { useState, useMemo, useEffect } from 'preact/hooks';
import htm from 'htm';
import type { TargetedEvent } from 'preact/compat';

import { ImageItem, BackgroundSettings } from '../../types';
// FIX: Imported UploadIcon, RegenerateIcon, and DeleteIcon to resolve component not found errors.
import { Loader, ImageUploader, ImageComparisonSlider, CheckIcon, SimpleLightbox, ViewIcon, EnhancedDownloadButton, DownloadIcon, UploadIcon, RegenerateIcon, DeleteIcon, CompareIcon, SideBySideIcon, SliderSwapIcon, GridIcon } from '../../components';
import { BackgroundSettingsPanel } from './BackgroundSettingsPanel';
import { changeBackground, upscaleImage } from '../../api';

const html = htm.bind(h);

const BackgroundEditor: FunctionalComponent = () => {
    const [originalImage, setOriginalImage] = useState<string | null>(null);
    const [generatedImages, setGeneratedImages] = useState<string[]>([]);
    const [selectedGeneratedImage, setSelectedGeneratedImage] = useState<string | null>(null);
    const [generating, setGenerating] = useState(false);
    const [error, setError] = useState('');
    const [lightboxImage, setLightboxImage] = useState<string | null>(null);
    const [comparisonMode, setComparisonMode] = useState<'slider' | 'side-by-side' | 'toggle'>('side-by-side');
    const [showOriginalToggle, setShowOriginalToggle] = useState(false);
    const [settings, setSettings] = useState<BackgroundSettings>({
        prompt: '',
        referenceImage: null,
        poseOption: 'keep',
        lightingEffect: 'none',
        numImages: 1,
        numberOfPeople: 'one',
        sharpenSubject: true,
        lightingIntensity: 75,
    });

    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => {
            if (e.key === 'Control' && originalImage && selectedGeneratedImage) {
                e.preventDefault();
                setComparisonMode('toggle');
                setShowOriginalToggle(prev => !prev);
            }
        };
        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, [originalImage, selectedGeneratedImage]);

    const handleGenerate = async () => {
        if (!originalImage) return;
        setGenerating(true);
        setError('');
        setGeneratedImages([]);
        setSelectedGeneratedImage(null);

        const results: (string | null)[] = [];
        for (let i = 0; i < settings.numImages; i++) {
            try {
                const result = await changeBackground(originalImage, settings);
                results.push(result);
            } catch (err) {
                console.error("Error generating one background:", err);
                const message = err instanceof Error ? err.message : String(err);
                setError(prev => prev ? `${prev}\nLỗi lần ${i+1}: ${message}`: `Lỗi lần ${i+1}: ${message}`);
                results.push(null);
            }
        }
        const successfulResults = results.filter((url): url is string => url !== null);

        setGeneratedImages(successfulResults);
        if (successfulResults.length > 0) {
            setSelectedGeneratedImage(successfulResults[0]);
        } else if (!error) {
            setError("Bạn cần nhập API Key tại tab Cài đặt trước khi sử dụng tính năng này.");
        }
        setGenerating(false);
    };

    const handleUpload = (image: string | null) => {
        setOriginalImage(image);
        setGeneratedImages([]);
        setSelectedGeneratedImage(null);
        setError('');
    };
    
    const handleDownload = () => {
        if (!selectedGeneratedImage) return;
        const link = document.createElement('a');
        link.href = selectedGeneratedImage;
        link.download = `background-changed-${Date.now()}.jpeg`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    const renderComparisonView = () => {
        const imageToCompare = showOriginalToggle ? originalImage : selectedGeneratedImage;

        if (!selectedGeneratedImage) {
            return html`<img src=${originalImage} style=${{ objectFit: 'contain', width: '100%', height: '100%' }} />`;
        }

        switch (comparisonMode) {
            case 'side-by-side':
                return html`
                    <div class="comparison-side-by-side">
                        <div class="comparison-pane">
                            <img src=${originalImage} alt="Original" />
                        </div>
                        <div class="comparison-pane">
                            <img src=${selectedGeneratedImage} alt="Generated" />
                        </div>
                    </div>`;
            case 'toggle':
                 return html`<img src=${imageToCompare} alt="Comparison" style=${{ objectFit: 'contain', width: '100%', height: '100%' }} />`;
            case 'slider':
            default:
                return html`<${ImageComparisonSlider} original=${originalImage} generated=${selectedGeneratedImage} objectFit="contain"/>`;
        }
    };

    return html`
        ${lightboxImage && html`
            <${SimpleLightbox} 
                imageUrl=${lightboxImage} 
                caption="Ảnh đã thay nền" 
                onClose=${() => setLightboxImage(null)} 
            />
        `}
        <div class="editor-layout">
            <${BackgroundSettingsPanel} settings=${settings} setSettings=${setSettings} onGenerate=${handleGenerate} generating=${generating} hasImage=${!!originalImage} />
            <div class="image-panel">
                 ${!originalImage ? html`
                    <${ImageUploader} onImageUpload=${(img: string) => handleUpload(img)} />
                ` : html`
                    <div class="image-panel-preview">
                        ${generating && html`<${Loader} text="AI đang thay đổi nền..." />`}
                        <div class="image-display-wrapper">
                            ${renderComparisonView()}
                            ${!generating && html`
                                <div class="restoration-toolbar">
                                    <button class="toolbar-btn" onClick=${() => handleUpload(null)} title="Tải ảnh khác" disabled=${generating}>
                                        <${UploadIcon} />
                                        <span>Tải ảnh khác</span>
                                    </button>
                                    <button class="toolbar-btn ${comparisonMode === 'toggle' ? 'active' : ''}" onClick=${() => setComparisonMode('toggle')} title="So sánh (Ctrl)" disabled=${!selectedGeneratedImage}>
                                        <${CompareIcon} />
                                        <span>So sánh</span>
                                    </button>
                                     <button class="toolbar-btn ${comparisonMode === 'slider' ? 'active' : ''}" onClick=${() => setComparisonMode('slider')} title="Chế độ trượt" disabled=${!selectedGeneratedImage}>
                                        <${SliderSwapIcon} />
                                        <span>Chế độ trượt</span>
                                    </button>
                                     <button class="toolbar-btn ${comparisonMode === 'side-by-side' ? 'active' : ''}" onClick=${() => setComparisonMode('side-by-side')} title="Song song" disabled=${!selectedGeneratedImage}>
                                        <${GridIcon} />
                                        <span>Song song</span>
                                    </button>
                                    <button class="toolbar-btn" onClick=${handleGenerate} title="Tạo lại" disabled=${generating}>
                                        <${RegenerateIcon} />
                                        <span>Tạo lại</span>
                                    </button>
                                    <button class="toolbar-btn" onClick=${handleDownload} title="Tải ảnh" disabled=${generating || !selectedGeneratedImage}>
                                        <${DownloadIcon} />
                                        <span>Tải ảnh</span>
                                    </button>
                                </div>
                            `}
                        </div>
                        ${generatedImages.length > 1 && html`
                            <div class="thumbnail-gallery">
                                ${generatedImages.map((url, index) => html`
                                    <div class="thumbnail-item">
                                        <img 
                                            src=${url} 
                                            alt="Generated ${index + 1}" 
                                            class=${selectedGeneratedImage === url ? 'active' : ''}
                                            onClick=${() => setSelectedGeneratedImage(url)}
                                        />
                                    </div>
                                `)}
                            </div>
                        `}
                        ${error && html`<div class="error-message" style=${{textAlign: 'left', whiteSpace: 'pre-wrap'}}>${error}</div>`}
                    </div>
                `}
            </div>
        </div>
    `;
};

const BatchBackgroundEditor: FunctionalComponent = () => {
    const [images, setImages] = useState<ImageItem[]>([]);
    // FIX: Changed state type to 'BackgroundSettings' and added 'numImages' to ensure the object is complete for API calls.
    const [settings, setSettings] = useState<BackgroundSettings>({
        prompt: '',
        referenceImage: null,
        poseOption: 'keep',
        lightingEffect: 'none',
        numImages: 1,
        numberOfPeople: 'one',
        sharpenSubject: true,
        lightingIntensity: 75,
    });
    const [processing, setProcessing] = useState(false);
    const [progress, setProgress] = useState(0);
    const [error, setError] = useState('');
    const [isDownloading, setIsDownloading] = useState('');
    const [lightboxImage, setLightboxImage] = useState<string | null>(null);
    const [downloadQuality, setDownloadQuality] = useState<'original' | '4k' | '8k'>('4k');

    const handleFileChange = (e: TargetedEvent<HTMLInputElement>) => {
        if (!e.currentTarget.files) return;
        // FIX: Explicitly type `file` as `File` to resolve type inference issue.
        const newImages: ImageItem[] = Array.from(e.currentTarget.files).map((file: File) => ({
            id: Date.now() + Math.random(), file, original: URL.createObjectURL(file), generated: null, status: 'pending'
        }));
        setImages(current => [...current, ...newImages]);
    };
    
    const readFileAsDataURL = (file: File): Promise<string> => new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = reject;
        reader.readAsDataURL(file);
    });

    const processQueue = async (tasks: ImageItem[], concurrency: number, processFn: (task: ImageItem) => Promise<void>) => {
        let completed = 0;
        const queue = [...tasks];
        const worker = async () => {
            while(queue.length > 0) {
                const task = queue.shift();
                if (task) {
                    await processFn(task);
                    completed++;
                    setProgress(Math.round((completed / tasks.length) * 100));
                    if (queue.length > 0) {
                        await new Promise(resolve => setTimeout(resolve, 2000)); // Wait 2 seconds before the next call
                    }
                }
            }
        };
        await Promise.all(Array(concurrency).fill(null).map(() => worker()));
    };

    const handleBatchGenerate = async () => {
        setProcessing(true);
        setProgress(0);
        setError('');
        const tasks = images.filter(img => img.status === 'pending' || img.status === 'error');
        
        const processTask = async (img: ImageItem) => {
            setImages(current => current.map(i => i.id === img.id ? { ...i, status: 'processing' } : i));
            try {
                const originalDataUrl = await readFileAsDataURL(img.file);
                const result = await changeBackground(originalDataUrl, settings);
                setImages(current => current.map(i => i.id === img.id ? { ...i, generated: result, status: 'done' } : i));
            } catch (err) {
                const message = err instanceof Error ? err.message : String(err);
                setError(message);
                console.error(`Error processing image ${img.id}:`, err);
                setImages(current => current.map(i => i.id === img.id ? { ...i, status: 'error' } : i));
                throw err;
            }
        };
        
        try {
            await processQueue(tasks, 1, processTask);
        } catch (e) {
            console.error("Batch processing stopped due to an error.", e);
        } finally {
            setProcessing(false);
        }
    };
    
    const regenerateImage = async (id: number) => {
        const imageToRegen = images.find(i => i.id === id);
        if (!imageToRegen) return;
        setError('');
        setImages(current => current.map(i => i.id === id ? { ...i, status: 'processing' } : i));
        try {
            const originalDataUrl = await readFileAsDataURL(imageToRegen.file);
            const result = await changeBackground(originalDataUrl, settings);
            setImages(current => current.map(i => i.id === id ? { ...i, generated: result, status: 'done' } : i));
        } catch (err) {
            const message = err instanceof Error ? err.message : String(err);
            setError(message);
            setImages(current => current.map(i => i.id === id ? { ...i, status: 'error' } : i));
        }
    };
    
    const deleteImage = (id: number) => setImages(current => current.filter(i => i.id !== id));
    
    const handleDownloadAll = async () => {
        setIsDownloading('Bắt đầu...');
        setError('');
        const imagesToDownload = images.filter(img => img.generated);

        for (let i = 0; i < imagesToDownload.length; i++) {
            const img = imagesToDownload[i];
            if (!img.generated) continue;
            try {
                let imageUrl = img.generated;
                setIsDownloading(`Đang xử lý ${i + 1}/${imagesToDownload.length}...`);
                if (downloadQuality !== 'original') {
                    imageUrl = await upscaleImage(img.generated, downloadQuality);
                }
                const link = document.createElement('a');
                link.href = imageUrl;
                link.download = `background-changed-${img.id}-${downloadQuality}.jpeg`;
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                await new Promise(resolve => setTimeout(resolve, 500)); // Small delay between downloads
            } catch (err) {
                const message = `Lỗi khi tải ảnh ${i + 1}.`;
                setError(message);
                console.error(message, err);
                break;
            }
        }
        setIsDownloading('');
    };
    
    const pendingCount = useMemo(() => images.filter(img => img.status === 'pending' || img.status === 'error').length, [images]);
    const buttonText = pendingCount > 0 ? `Thay nền ${pendingCount} ảnh` : 'Thay nền';

    return html`
        ${lightboxImage && html`
            <${SimpleLightbox} 
                imageUrl=${lightboxImage} 
                caption="Ảnh đã thay nền" 
                onClose=${() => setLightboxImage(null)} 
            />
        `}
        <div class="batch-editor-layout">
            <${BackgroundSettingsPanel} 
                settings=${settings} 
                setSettings=${setSettings}
                onGenerate=${handleBatchGenerate} 
                generating=${processing} 
                hasImage=${pendingCount > 0} 
                buttonText=${buttonText} isBatch=${true} />
            <div class="batch-panel">
                 <div class="actions" style=${{ justifyContent: 'space-between', marginBottom: '1.5rem', flexWrap: 'wrap', gap: '1rem'}}>
                     <button class="btn btn-secondary" onClick=${() => document.getElementById('batch-bg-file-input')?.click()}>
                         <${UploadIcon} /> Thêm ảnh
                    </button>
                     <input type="file" id="batch-bg-file-input" multiple accept="image/*" style=${{display: 'none'}} onChange=${handleFileChange} />
                    <div style=${{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                        <div class="toggle-group" style=${{ flexShrink: 0 }}>
                            <button class=${`toggle-btn ${downloadQuality === 'original' ? 'active' : ''}`} onClick=${() => setDownloadQuality('original')}>Gốc</button>
                            <button class=${`toggle-btn ${downloadQuality === '4k' ? 'active' : ''}`} onClick=${() => setDownloadQuality('4k')}>4K</button>
                            <button class=${`toggle-btn ${downloadQuality === '8k' ? 'active' : ''}`} onClick=${() => setDownloadQuality('8k')}>8K</button>
                        </div>
                        <button class="btn btn-primary" onClick=${handleDownloadAll} disabled=${images.every(img => !img.generated) || !!isDownloading}>
                            ${isDownloading ? isDownloading : html`<${DownloadIcon} /> Tải tất cả`}
                        </button>
                    </div>
                </div>
                
                ${processing && html`
                    <div class="progress-bar">
                        <div class="progress-bar-inner" style=${{ width: `${progress}%` }}></div>
                        <span class="progress-label">${progress}%</span>
                    </div>
                `}
                
                ${error && html`<div class="error-message" style=${{marginTop: '1rem'}}>${error}</div>`}
    
                <div class="batch-grid">
                    ${images.map(img => html`
                        <div class="batch-item" onClick=${() => img.generated && setLightboxImage(img.generated)}>
                            <div class="image-container">
                                <img src=${img.generated || img.original} />
                                ${img.status === 'processing' && html`<${Loader} text="Đang xử lý..." />`}
                                ${img.status === 'error' && html`<div class="error-badge">Lỗi</div>`}
                            </div>
                            <div class="batch-item-actions">
                                <button class="batch-item-btn" title="Tạo lại" onClick=${(e: MouseEvent) => { e.stopPropagation(); regenerateImage(img.id); }}><${RegenerateIcon} /></button>
                                <button class="batch-item-btn" title="Xóa" onClick=${(e: MouseEvent) => { e.stopPropagation(); deleteImage(img.id); }}><${DeleteIcon} /></button>
                            </div>
                        </div>
                    `)}
                     ${images.length === 0 && html`
                        <div class="image-panel-content" style=${{
                            gridColumn: '1 / -1',
                            display: 'flex',
                            flexDirection: 'column',
                            alignItems: 'center',
                            justifyContent: 'center',
                            minHeight: '300px',
                            padding: '2rem'
                        }}>
                             <${UploadIcon} class="placeholder-icon" style=${{width: '80px', height: '80px', marginBottom: '1.5rem'}}/>
                             <h4 style=${{fontSize: '1.1rem', fontWeight: '600', marginBottom: '0.5rem', textAlign: 'center'}}>Thay Nền Hàng Loạt</h4>
                             <p class="placeholder-text" style=${{fontSize: '0.9rem', color: 'var(--text-secondary)', margin: 0, textAlign: 'center'}}>Chọn nhiều ảnh để thay nền đồng loạt.</p>
                        </div>
                     `}
                </div>
            </div>
        </div>
    `;
};

export const BackgroundApp: FunctionalComponent = () => {
    const [activeTab, setActiveTab] = useState('single');
    return html`
         <div>
            <div class="tabs">
                <button class="tab ${activeTab === 'single' ? 'active' : ''}" onClick=${() => setActiveTab('single')}>Chỉnh sửa đơn</button>
                <button class="tab ${activeTab === 'batch' ? 'active' : ''}" onClick=${() => setActiveTab('batch')}>Chỉnh sửa hàng loạt</button>
            </div>
            ${activeTab === 'single' ? html`<${BackgroundEditor} />` : html`<${BatchBackgroundEditor} />`}
        </div>
    `;
};