/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { h, FunctionalComponent } from 'preact';
import { useState } from 'preact/hooks';
import htm from 'htm';
import { Loader, ImageUploader, ImageComparisonSlider, DownloadIcon, ImageIcon, Icon4K, Icon8K } from '../../components';
import { upscaleImage } from '../../api';

const html = htm.bind(h);

export const UpscalerApp: FunctionalComponent = () => {
    const [originalImage, setOriginalImage] = useState<string | null>(null);
    const [generatedImage, setGeneratedImage] = useState<string | null>(null);
    const [generating, setGenerating] = useState<false | '4k' | '8k'>(false);
    const [error, setError] = useState('');
    const [upscaledVersion, setUpscaledVersion] = useState<'4k' | '8k' | null>(null);

    const handleImageUpload = (dataUrl: string | null) => {
        setOriginalImage(dataUrl);
        setGeneratedImage(null);
        setError('');
        setUpscaledVersion(null);
    };

    const handleDownload = () => {
        if (!generatedImage) return;
        const link = document.createElement('a');
        link.href = generatedImage;
        link.download = `upscaled-${upscaledVersion || 'image'}.jpeg`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    const handleUpscale = async (target: '4k' | '8k') => {
        if (!originalImage || generating || generatedImage) return;
        setGenerating(target);
        setError('');
        setUpscaledVersion(null);
        try {
            const result = await upscaleImage(originalImage, target);
            setGeneratedImage(result);
            setUpscaledVersion(target);
        } catch (err) {
            setError(err instanceof Error ? err.message : String(err));
        } finally {
            setGenerating(false);
        }
    };
    
    const handleReset = () => {
        setOriginalImage(null);
        setGeneratedImage(null);
        setError('');
        setUpscaledVersion(null);
    };

    return html`
        <div class="upscaler-page-container">
            ${!originalImage ? html`
                <div class="page-header" style=${{textAlign: 'center', maxWidth: '800px', margin: '0 auto 2rem auto'}}>
                    <h1>Làm Nét Ảnh AI</h1>
                    <p class="subtitle">Tải ảnh lên và để AI biến nó thành một kiệt tác 4K hoặc 8K siêu sắc nét.</p>
                </div>
                <div class="upscaler-upload-container">
                    <${ImageUploader} onImageUpload=${(url: string) => handleImageUpload(url)} id="upscaler-uploader" />
                </div>
            ` : html`
                <div class="upscaler-editor-layout">
                    <main class="upscaler-image-display">
                        ${generating && html`<${Loader} text=${`Đang nâng cấp ảnh lên ${generating.toUpperCase()}...`} />`}
                        <div class="image-display-wrapper">
                             <${ImageComparisonSlider} original=${originalImage} generated=${generatedImage} objectFit="contain" />
                        </div>
                    </main>
                    <aside class="settings-panel">
                        <div class="form-section">
                            <h3 class="form-section-title">Chọn chất lượng làm nét</h3>
                            <div class="upscaler-options-grid" style=${{marginTop: '1rem'}}>
                                <div 
                                    class="upscaler-option-card ${(generating || generatedImage) ? 'disabled' : ''}"
                                    onClick=${() => handleUpscale('4k')}
                                >
                                   <div class="icon"><${Icon4K} /></div>
                                   <h4>Làm Nét 4K</h4>
                                   <p>Tốt cho màn hình lớn và bản in chất lượng cao.</p>
                                </div>
                                <div 
                                    class="upscaler-option-card ${(generating || generatedImage) ? 'disabled' : ''}"
                                    onClick=${() => handleUpscale('8k')}
                                >
                                    <div class="icon"><${Icon8K} /></div>
                                   <h4>Làm Nét 8K</h4>
                                   <p>Chất lượng cao nhất cho các dự án chuyên nghiệp.</p>
                                </div>
                            </div>
                        </div>

                        ${error && html`<div class="error-message" style=${{width: '100%'}}>${error}</div>`}

                        ${generatedImage && html`
                            <div class="form-section" style=${{marginTop: '1.5rem', borderTop: '1px solid var(--border-color)', paddingTop: '1.5rem'}}>
                                <h3 class="form-section-title">Thao tác</h3>
                                <div style=${{ display: 'flex', flexDirection: 'column', gap: '0.75rem', width: '100%'}}>
                                    <button class="btn btn-primary" onClick=${handleDownload} disabled=${generating}>
                                        <${DownloadIcon} /> Tải về (${upscaledVersion?.toUpperCase()})
                                    </button>
                                    <button class="btn btn-secondary" onClick=${handleReset} disabled=${generating}>Bắt đầu lại</button>
                                </div>
                            </div>
                        `}
                    </aside>
                </div>
            `}
        </div>
    `;
};