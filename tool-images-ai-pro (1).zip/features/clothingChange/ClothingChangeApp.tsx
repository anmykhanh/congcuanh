/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { h, FunctionalComponent } from 'preact';
import { useState } from 'preact/hooks';
import htm from 'htm';
import { ClothingChangeSettings } from '../../types';
import { Loader, ImageUploader, ImageComparisonSlider, ImageActionsToolbar, ImageIcon } from '../../components';
import { ClothingChangeSettingsPanel } from './ClothingChangeSettingsPanel';
import { changeClothing } from '../../api';
import { addHistoryItem } from '../../history';
import { TABS } from '../../constants';

const html = htm.bind(h);

const initialSettings: ClothingChangeSettings = {
    clothingImage: null,
    clothingPrompt: '',
    numberOfPeople: 'one',
    poseOption: 'keep',
    sharpenSubject: true,
    lightingEffect: 'none',
    lightingIntensity: 75,
    numImages: 1,
};

export const ClothingChangeApp: FunctionalComponent = () => {
    const [originalImage, setOriginalImage] = useState<string | null>(null);
    const [generatedImages, setGeneratedImages] = useState<string[]>([]);
    const [selectedGeneratedImage, setSelectedGeneratedImage] = useState<string | null>(null);
    const [generating, setGenerating] = useState(false);
    const [error, setError] = useState('');
    const [settings, setSettings] = useState<ClothingChangeSettings>(initialSettings);

    const handleGenerate = async () => {
        if (!originalImage) return;
        setGenerating(true);
        setError('');
        setGeneratedImages([]);
        setSelectedGeneratedImage(null);

        const results: string[] = [];
        const featureInfo = TABS.find(t => t.id === 'clothing-change');

        for (let i = 0; i < settings.numImages; i++) {
            try {
                const result = await changeClothing(originalImage, settings);
                results.push(result);
                await addHistoryItem({
                    original: originalImage,
                    generated: result,
                    feature: 'clothing-change',
                    featureLabel: featureInfo?.label || 'Thay Đổi Trang Phục',
                });
            } catch (err) {
                const message = err instanceof Error ? err.message : String(err);
                setError(prev => prev ? `${prev}\nLỗi lần ${i + 1}: ${message}` : `Lỗi lần ${i + 1}: ${message}`);
                break; // Stop on first error
            }
        }
        
        setGeneratedImages(results);
        if (results.length > 0) {
            setSelectedGeneratedImage(results[0]);
        }
        setGenerating(false);
    };
    
    const handleUpload = (image: string | null) => {
        setOriginalImage(image);
        setGeneratedImages([]);
        setSelectedGeneratedImage(null);
        setError('');
    }
    
    return html`
        <div class="editor-layout">
            <${ClothingChangeSettingsPanel} 
                settings=${settings} 
                setSettings=${setSettings} 
                onGenerate=${handleGenerate} 
                generating=${generating} 
                hasImage=${!!originalImage} 
            />
            <div class="image-panel">
                ${!originalImage ? html`
                    <${ImageUploader} onImageUpload=${(img: string) => handleUpload(img)} />
                ` : html`
                    <div class="image-panel-preview">
                        ${generating && html`<${Loader} text="AI đang thay đổi trang phục..." />`}
                        <div class="image-display-wrapper">
                            <${ImageComparisonSlider} original=${originalImage} generated=${selectedGeneratedImage} objectFit="contain"/>
                            <${ImageActionsToolbar}
                                generatedImage=${selectedGeneratedImage}
                                filename="clothing-changed.jpeg"
                                onReset=${() => handleUpload(null)}
                                isGenerating=${generating}
                            />
                        </div>
                         ${generatedImages.length > 1 && html`
                            <div class="thumbnail-gallery">
                                ${generatedImages.map((url, index) => html`
                                    <div class="thumbnail-item">
                                        <img 
                                            src=${url} 
                                            alt="Generated ${index + 1}" 
                                            class=${selectedGeneratedImage === url ? 'active' : ''}
                                            onClick=${() => setSelectedGeneratedImage(url)}
                                        />
                                        <span class="thumbnail-label">Ảnh ${index+1}</span>
                                    </div>
                                `)}
                            </div>
                        `}
                        ${error && html`<div class="error-message">${error}</div>`}
                    </div>
                `}
            </div>
        </div>
    `;
};