/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { h, FunctionalComponent } from 'preact';
import { useState } from 'preact/hooks';
import htm from 'htm';

import { MockupSettings } from '../../types';
// FIX: Replaced non-existent `HighQualityDownloadButton` with `EnhancedDownloadButton`.
import { Loader, ImageComparisonSlider, EnhancedDownloadButton, DiamondIcon, ImageUploader, ImageActionsToolbar } from '../../components';
import { MockupSettingsPanel } from './MockupSettingsPanel';
import { createProductMockup } from '../../api';

const html = htm.bind(h);

const MockupEditor: FunctionalComponent = () => {
    const [settings, setSettings] = useState<MockupSettings>({
        productImage: null,
        characterImage: null,
        characterPrompt: '',
        scenePrompt: '',
    });
    const [generatedImage, setGeneratedImage] = useState<string | null>(null);
    const [generating, setGenerating] = useState(false);
    const [error, setError] = useState('');

    const handleGenerate = async () => {
        if (!settings.productImage) return;
        setGenerating(true);
        setError('');
        try {
            const result = await createProductMockup(settings);
            setGeneratedImage(result);
        } catch (err) {
            if (err instanceof Error) {
                setError(err.message);
            } else {
                setError(String(err));
            }
        } finally {
            setGenerating(false);
        }
    };
    
    const handleReset = () => {
        setSettings({
            productImage: null,
            characterImage: null,
            characterPrompt: '',
            scenePrompt: '',
        });
        setGeneratedImage(null);
        setError('');
    };

    return html`
        <div class="editor-layout">
            <${MockupSettingsPanel} settings=${settings} setSettings=${setSettings} onGenerate=${handleGenerate} generating=${generating} />
            <div class="image-panel">
                ${!settings.productImage ? html`
                    <${ImageUploader} onImageUpload=${(img: string) => setSettings(s => ({...s, productImage: img}))} />
                ` : html`
                    <div class="image-panel-preview">
                        ${generating && html`<${Loader} text="AI đang tạo mockup sản phẩm..." />`}
                        <div class="image-display-wrapper">
                            <${ImageComparisonSlider} original=${settings.productImage} generated=${generatedImage} objectFit="contain" />
                            <${ImageActionsToolbar}
                                generatedImage=${generatedImage}
                                filename="product-mockup.jpeg"
                                onReset=${handleReset}
                                isGenerating=${generating}
                            />
                        </div>
                        ${error && html`<div class="error-message">${error}</div>`}
                    </div>
                `}
            </div>
        </div>
    `;
};

export const MockupApp: FunctionalComponent = () => {
    return html`<${MockupEditor} />`;
}