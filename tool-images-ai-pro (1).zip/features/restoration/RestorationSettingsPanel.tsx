/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { h, FunctionalComponent } from 'preact';
import { useState } from 'preact/hooks';
import htm from 'htm';
import type { TargetedEvent } from 'preact/compat';
import { RestorationSettings, CommonSettingsPanelProps } from '../../types';
import { analyzeImageForRestoration, describeImageForRestoration } from '../../api';
import { UploadIcon } from '../../components';

const html = htm.bind(h);

interface RestorationSettingsPanelProps extends CommonSettingsPanelProps {
    settings: RestorationSettings;
    setSettings: (updater: (s: RestorationSettings) => RestorationSettings) => void;
    originalImage?: string | null;
    isBatch?: boolean;
    onImageChange?: () => void;
}

export const RestorationSettingsPanel: FunctionalComponent<RestorationSettingsPanelProps> = ({ settings, setSettings, onGenerate, generating, hasImage, buttonText, originalImage, isBatch = false, onImageChange }) => {
    const [activePreset, setActivePreset] = useState<string | null>(null);
    const [isAnalyzing, setIsAnalyzing] = useState<false | 'analyze' | 'describe'>(false);
    const [analysisError, setAnalysisError] = useState('');

    const handleAutoAnalyze = async () => {
        if (!originalImage || isAnalyzing) return;
        setIsAnalyzing('analyze');
        setAnalysisError('');
        try {
            const analysisResult = await analyzeImageForRestoration(originalImage);
            setSettings(s => ({ ...s, ...analysisResult }));
        } catch (err) {
            setAnalysisError(err instanceof Error ? err.message : 'Lỗi phân tích ảnh.');
        } finally {
            setIsAnalyzing(false);
        }
    };
    
    const handleCreateDescription = async () => {
        if (!originalImage || isAnalyzing) return;
        setIsAnalyzing('describe');
        setAnalysisError('');
        try {
            const description = await describeImageForRestoration(originalImage);
            setSettings(s => ({ ...s, advancedPrompt: description }));
        } catch (err) {
            setAnalysisError(err instanceof Error ? err.message : 'Lỗi tạo mô tả.');
        } finally {
            setIsAnalyzing(false);
        }
    };

    const handleCheckboxChange = (e: TargetedEvent<HTMLInputElement>) => {
        setActivePreset(null);
        const { name, checked } = e.currentTarget;
        setSettings(s => ({ ...s, [name]: checked }));
    };

    const handlePreset = (preset: string) => {
        setActivePreset(preset);
        const defaults = {
            colorize: false, highQuality: false, redrawHair: false, sharpenBackground: false,
            adhereToFace: false, sharpenWrinkles: false, isVietnamese: false, redrawClothing: false,
            advancedPrompt: '', // Reset advanced prompt on preset click
        };
        switch(preset) {
            case 'hq':
                setSettings(s => ({ ...s, ...defaults, highQuality: true, adhereToFace: true, isVietnamese: true }));
                break;
            case 'color':
                setSettings(s => ({ ...s, ...defaults, colorize: true, highQuality: true, adhereToFace: true, isVietnamese: true }));
                break;
            case 'heavy_damage':
                setSettings(s => ({ ...s, ...defaults, highQuality: true, redrawHair: true, redrawClothing: true, adhereToFace: true }));
                break;
            case 'deyellow':
                 setSettings(s => ({ ...s, ...defaults, highQuality: true, advancedPrompt: 'Khử ố vàng và phai màu' }));
                 break;
            case 'advanced_portrait':
                 setSettings(s => ({ ...s, ...defaults, highQuality: true, redrawHair: true, adhereToFace: true, sharpenWrinkles: true }));
                 break;
            case 'painting':
                 setSettings(s => ({ ...s, ...defaults, highQuality: true, advancedPrompt: 'Phục hồi bức tranh vẽ' }));
                 break;
            case 'detailed':
                setSettings(s => ({ ...s, ...defaults, highQuality: true, redrawHair: true, redrawClothing: true, sharpenBackground: true, adhereToFace: true }));
                break;
            case 'colorize_bw':
                 setSettings(s => ({ ...s, ...defaults, colorize: true, advancedPrompt: 'Làm màu cho ảnh đen trắng' }));
                 break;
        }
    };
    
    const presets = [
        { id: 'hq', label: 'Phục chế chất lượng cao' },
        { id: 'color', label: 'Phục chế & Tô màu' },
        { id: 'heavy_damage', label: 'Tái tạo ảnh hỏng nặng' },
        { id: 'deyellow', label: 'Khử ố vàng & Phai màu' },
        { id: 'advanced_portrait', label: 'Phục chế chân dung nâng cao' },
        { id: 'painting', label: 'Phục hồi bức tranh vẽ' },
        { id: 'detailed', label: 'Phục hồi và vẽ lại thật chi tiết' },
        { id: 'colorize_bw', label: 'Làm màu cho ảnh đen trắng' },
    ];

    return html`
        <div class="settings-panel">
            <div class="form-group">
                <div class="toggle-group" style="gap: 1rem;">
                    <button 
                        class="toggle-btn" 
                        style="flex:1;"
                        onClick=${handleAutoAnalyze}
                        disabled=${!originalImage || !!isAnalyzing || generating}
                    >
                        ${isAnalyzing === 'analyze' ? 'Đang phân tích...' : 'Tự động phân tích'}
                    </button>
                    <button 
                        class="toggle-btn" 
                        style="flex:1;"
                        onClick=${handleCreateDescription}
                        disabled=${!originalImage || !!isAnalyzing || generating}
                    >
                        ${isAnalyzing === 'describe' ? 'Đang tạo...' : 'Tạo mô tả'}
                    </button>
                </div>
                ${analysisError && html`<div class="error-message" style="margin-top: 1rem; text-align: left;">${analysisError}</div>`}
            </div>
            
            <div class="form-group">
                <label class="form-section-title">Tùy chọn phục hồi</label>
                <div class="checkbox-grid-restoration">
                    <label><input type="checkbox" name="colorize" checked=${settings.colorize} onChange=${handleCheckboxChange} /> Tô màu</label>
                    <label><input type="checkbox" name="adhereToFace" checked=${settings.adhereToFace} onChange=${handleCheckboxChange} /> Bám theo chi tiết khuôn mặt</label>
                    <label><input type="checkbox" name="highQuality" checked=${settings.highQuality} onChange=${handleCheckboxChange} /> Chất lượng cao</label>
                    <label><input type="checkbox" name="sharpenWrinkles" checked=${settings.sharpenWrinkles} onChange=${handleCheckboxChange} /> Làm nét nếp nhăn</label>
                    <label><input type="checkbox" name="redrawHair" checked=${settings.redrawHair} onChange=${handleCheckboxChange} /> Vẽ lại tóc chi tiết</label>
                    <label><input type="checkbox" name="isVietnamese" checked=${settings.isVietnamese} onChange=${handleCheckboxChange} /> Người Việt Nam</label>
                    <label><input type="checkbox" name="sharpenBackground" checked=${settings.sharpenBackground} onChange=${handleCheckboxChange} /> Làm rõ nét hậu cảnh</label>
                    <label><input type="checkbox" name="redrawClothing" checked=${settings.redrawClothing} onChange=${handleCheckboxChange} /> Vẽ lại trang phục</label>
                </div>
            </div>

             <div class="form-group-row">
                <div class="form-group">
                    <label for="gender">Giới tính</label>
                    <select id="gender" value=${settings.gender} onChange=${(e: TargetedEvent<HTMLSelectElement>) => { setActivePreset(null); setSettings(s => ({...s, gender: e.currentTarget.value}))}}>
                        <option value="auto">Tự động</option>
                        <option value="male">Nam</option>
                        <option value="female">Nữ</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="age">Độ tuổi</label>
                    <select id="age" value=${settings.age} onChange=${(e: TargetedEvent<HTMLSelectElement>) => { setActivePreset(null); setSettings(s => ({...s, age: e.currentTarget.value}))}}>
                        <option value="auto">Tự động</option>
                        <option value="child">Trẻ em</option>
                        <option value="young-adult">Thanh niên</option>
                        <option value="adult">Trung niên</option>
                        <option value="senior">Lớn tuổi</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label for="smile">Nụ cười</label>
                <select id="smile" value=${settings.smile} onChange=${(e: TargetedEvent<HTMLSelectElement>) => { setActivePreset(null); setSettings(s => ({...s, smile: e.currentTarget.value}))}}>
                    <option value="auto">Tự động</option>
                    <option value="none">Không cười</option>
                    <option value="slight">Cười nhẹ</option>
                </select>
            </div>

             <div class="form-group">
                <label class="form-section-label">Hoặc chọn một mẫu có sẵn</label>
                <div class="option-grid restoration-presets">
                    ${presets.map(p => html`<button class="option-btn ${activePreset === p.id ? 'active' : ''}" onClick=${() => handlePreset(p.id)}>${p.label}</button>`)}
                </div>
            </div>
            
             <div class="form-group">
                <label for="advanced-prompt">Yêu cầu nâng cao (Tùy chọn)</label>
                <textarea 
                    id="advanced-prompt" 
                    value=${settings.advancedPrompt}
                    onInput=${(e: TargetedEvent<HTMLTextAreaElement>) => { setActivePreset(null); setSettings(s => ({ ...s, advancedPrompt: e.currentTarget.value }))}}
                    disabled=${!!activePreset}
                ></textarea>
            </div>

            <div class="form-group">
                <label for="custom-prompt">Yêu cầu tùy chỉnh (Prompt):</label>
                <textarea 
                    id="custom-prompt" 
                    rows="6"
                    value=${settings.customPrompt}
                    onInput=${(e: TargetedEvent<HTMLTextAreaElement>) => { setActivePreset(null); setSettings(s => ({ ...s, customPrompt: e.currentTarget.value }))}}
                    disabled=${!!activePreset}
                ></textarea>
            </div>
            
            ${!isBatch && html`
                <div class="form-group">
                    <label for="num-results">Số lượng kết quả (tối đa 5)</label>
                    <input class="number-input" type="number" id="num-results" min="1" max="5" value=${settings.numResults} onInput=${(e: TargetedEvent<HTMLInputElement>) => { setActivePreset(null); setSettings(s => ({...s, numResults: parseInt(e.currentTarget.value, 10) || 1}))}} />
                </div>
            `}

            <button class="btn btn-primary" onClick=${onGenerate} disabled=${generating || !hasImage} style=${{width: '100%', marginTop: '0.5rem', padding: '0.85rem'}}>
                ${generating ? 'Đang phục chế...' : (buttonText || 'PHỤC HỒI ẢNH')}
            </button>
        </div>
    `;
};