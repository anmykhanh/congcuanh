
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { h, FunctionalComponent } from 'preact';
import { useState } from 'preact/hooks';
import htm from 'htm';
import type { TargetedEvent } from 'preact/compat';

const html = htm.bind(h);

interface LoginComponentProps {
    onActivate: (key: string) => Promise<void>;
    error: string;
}

export const LoginComponent: FunctionalComponent<LoginComponentProps> = ({ onActivate, error }) => {
    const [activationKey, setActivationKey] = useState('');
    const [loading, setLoading] = useState(false);

    const handleSubmit = async (e: TargetedEvent) => {
        e.preventDefault();
        setLoading(true);
        try {
            await onActivate(activationKey);
        } catch (err) {
            // Error is handled by the parent component's state
        } finally {
            setLoading(false);
        }
    };

    return html`
        <div class="login-container">
            <div class="login-form">
                <h2>Kích hoạt Tool</h2>
                <h3 class="login-form-magic-title">TOOL IMAGES AI PRO</h3>
                <p class="subtitle">Vui lòng nhập mã số key để kích hoạt công cụ.</p>
                ${error && html`<div class="error-message" style=${{marginBottom: '1.5rem'}}>${error}</div>`}
                <form onSubmit=${handleSubmit}>
                    <div class="form-group" style=${{marginBottom: '1.5rem'}}>
                        <label for="activation-key">Mã số key kích hoạt</label>
                        <input 
                            type="password" 
                            id="activation-key" 
                            value=${activationKey} 
                            onInput=${(e: TargetedEvent<HTMLInputElement>) => setActivationKey(e.currentTarget.value)} 
                            required
                            placeholder="Nhập mã số key của bạn..."
                        />
                    </div>
                    <button type="submit" class="btn btn-primary" style=${{width: '100%'}} disabled=${loading}>
                        ${loading ? 'Đang kiểm tra...' : 'Kích hoạt'}
                    </button>
                </form>
            </div>
        </div>
    `;
};
