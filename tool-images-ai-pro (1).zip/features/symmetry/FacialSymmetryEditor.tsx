/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { h, FunctionalComponent } from 'preact';
import { useState } from 'preact/hooks';
import htm from 'htm';

import { SymmetrySettings } from '../../types';
// FIX: Replaced non-existent `HighQualityDownloadButton` with `EnhancedDownloadButton`.
import { Loader, ImageUploader, ImageComparisonSlider, EnhancedDownloadButton, DiamondIcon, ImageActionsToolbar } from '../../components';
import { SymmetrySettingsPanel } from './SymmetrySettingsPanel';
import { correctFacialSymmetry } from '../../api';

const html = htm.bind(h);

export const FacialSymmetryEditor: FunctionalComponent = () => {
    const [originalImage, setOriginalImage] = useState<string | null>(null);
    const [generatedImage, setGeneratedImage] = useState<string | null>(null);
    const [generating, setGenerating] = useState(false);
    const [error, setError] = useState('');
    
    const createDefaultAdjustments = () => ({
        enabled: false,
        intensity: 50,
    });

    const [settings, setSettings] = useState<SymmetrySettings>({
        adjustments: {
            smoothHair: createDefaultAdjustments(),
            balanceEyes: createDefaultAdjustments(),
            equalizeEyeSize: createDefaultAdjustments(),
            correctEyeGaze: createDefaultAdjustments(),
            narrowNose: createDefaultAdjustments(),
            straightenNose: createDefaultAdjustments(),
            liftNoseTip: createDefaultAdjustments(),
            centerMouth: createDefaultAdjustments(),
            evenTeeth: createDefaultAdjustments(),
            removeLipWrinkles: createDefaultAdjustments(),
            slimJawline: createDefaultAdjustments(),
            adjustChin: createDefaultAdjustments(),
        },
    });

    const handleGenerate = async () => {
        if (!originalImage) return;
        setGenerating(true);
        setError('');
        try {
            const result = await correctFacialSymmetry(originalImage, settings);
            setGeneratedImage(result);
        } catch (err) {
            if (err instanceof Error) {
                setError(err.message);
            } else {
                setError(String(err));
            }
        } finally {
            setGenerating(false);
        }
    };
    
    const handleUpload = (image: string | null) => {
        setOriginalImage(image);
        setGeneratedImage(null);
    }

    return html`
        <div class="editor-layout">
            <${SymmetrySettingsPanel} settings=${settings} setSettings=${setSettings} onGenerate=${handleGenerate} generating=${generating} hasImage=${!!originalImage} />
            <div class="image-panel">
                ${!originalImage ? html`
                    <${ImageUploader} onImageUpload=${(img: string) => handleUpload(img)} />
                ` : html`
                    <div class="image-panel-preview">
                        ${generating && html`<${Loader} text="AI đang phân tích và chỉnh sửa..." />`}
                        <div class="image-display-wrapper">
                            <${ImageComparisonSlider} original=${originalImage} generated=${generatedImage} objectFit="contain" />
                            <${ImageActionsToolbar}
                                generatedImage=${generatedImage}
                                filename="symmetric-photo.jpeg"
                                onReset=${() => handleUpload(null)}
                                isGenerating=${generating}
                            />
                        </div>
                        ${error && html`<div class="error-message">${error}</div>`}
                    </div>
                `}
            </div>
        </div>
    `;
};