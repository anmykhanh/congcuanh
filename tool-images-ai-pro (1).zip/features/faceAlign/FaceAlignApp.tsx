/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { h, FunctionalComponent } from 'preact';
import { useState, useRef } from 'preact/hooks';
import htm from 'htm';
import type { TargetedEvent } from 'preact/compat';
// FIX: Replaced non-existent `HighQualityDownloadButton` with `EnhancedDownloadButton`.
import { Loader, ImageIcon, EnhancedDownloadButton, DiamondIcon } from '../../components';
import { alignFace, upscaleImage } from '../../api';

const html = htm.bind(h);

export const FaceAlignApp: FunctionalComponent = () => {
    const [originalImage, setOriginalImage] = useState<string | null>(null);
    const [alignedImage, setAlignedImage] = useState<string | null>(null);
    const [finalImage, setFinalImage] = useState<string | null>(null); // This will hold the upscaled version if created
    const [zoom, setZoom] = useState(100);
    const [isAligning, setIsAligning] = useState(false);
    const [isUpscaling, setIsUpscaling] = useState<false | '4k' | '8k'>(false);
    const [error, setError] = useState('');
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleFileChange = (e: TargetedEvent<HTMLInputElement>) => {
        const file = e.currentTarget.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (loadEvent) => {
                if (loadEvent.target?.result) {
                    const imageUrl = loadEvent.target.result as string;
                    setOriginalImage(imageUrl);
                    setAlignedImage(null);
                    setFinalImage(null);
                    setError('');
                    setZoom(100);
                }
            };
            reader.readAsDataURL(file);
        }
    };
    
    const handleAlign = async () => {
        if (!originalImage) return;
        setIsAligning(true);
        setError('');
        try {
            const result = await alignFace(originalImage);
            setAlignedImage(result);
            setFinalImage(result);
        } catch (err) {
            setError(err instanceof Error ? err.message : String(err));
        } finally {
            setIsAligning(false);
        }
    };

    const handleUpscale = async (target: '4k' | '8k') => {
        const imageToUpscale = alignedImage;
        if (!imageToUpscale) return;
        setIsUpscaling(target);
        setError('');
        try {
            const result = await upscaleImage(imageToUpscale, target);
            setFinalImage(result);
        } catch (err) {
            setError(err instanceof Error ? err.message : String(err));
        } finally {
            setIsUpscaling(false);
        }
    };
    
    const isLoading = isAligning || isUpscaling;
    const loadingText = isAligning 
        ? "Đang cân chỉnh mặt..." 
        : isUpscaling 
        ? `Đang nâng cấp lên ${isUpscaling}...` 
        : "";

    return html`
        <div class="face-align-app">
            <input type="file" ref=${fileInputRef} onChange=${handleFileChange} accept="image/*" style=${{ display: 'none' }} />
            
            <div class="face-align-header">
                <h1>CĂN CHỈNH THẲNG MẶT</h1>
                <p>Tải ảnh lên VIP ONE sẽ giúp bạn cân chỉnh thẳng mặt.</p>
            </div>

            <div class="face-align-actions">
                <button class="btn btn-primary" onClick=${() => fileInputRef.current?.click()}>Chọn Ảnh</button>
                <button class="btn btn-secondary" onClick=${handleAlign} disabled=${!originalImage || isLoading}>
                    ${isAligning ? 'Đang xử lý...' : 'Cân Chỉnh Mặt'}
                </button>
            </div>

            ${error && html`<div class="error-message" style=${{maxWidth: '800px', margin: '0 auto 2rem auto'}}>${error}</div>`}

            <div class="face-align-panels">
                <div class="image-panel-labeled">
                    <h3>ẢNH GỐC</h3>
                    <div class="image-display-box">
                        ${originalImage ? html`
                            <img src=${originalImage} alt="Original" />
                        ` : html`
                            <div class="image-placeholder">
                                <${ImageIcon} />
                                <span>Nhấp "Chọn Ảnh" để bắt đầu</span>
                            </div>
                        `}
                    </div>
                </div>

                <div class="image-panel-labeled">
                    <h3>ẢNH ĐÃ CÂN CHỈNH</h3>
                    <div class="image-display-box">
                        ${isLoading && html`<${Loader} text=${loadingText} />`}
                        ${finalImage ? html`
                            <img src=${finalImage} alt="Aligned" style=${{ transform: `scale(${zoom / 100})` }} />
                        ` : html`
                            <div class="image-placeholder">
                                <${ImageIcon} />
                                <span>Kết quả sẽ hiện ở đây</span>
                            </div>
                        `}
                    </div>
                    <div class="controls-panel">
                        <div class="slider-control zoom-control">
                            <div class="slider-label">
                                <span>Thu phóng:</span>
                                <span class="value">${zoom}%</span>
                            </div>
                            <input 
                                type="range" 
                                min="100" 
                                max="400" 
                                value=${zoom} 
                                onInput=${(e: TargetedEvent<HTMLInputElement>) => setZoom(parseInt(e.currentTarget.value, 10))}
                                disabled=${!finalImage}
                            />
                        </div>
                        <${EnhancedDownloadButton} baseImageUrl=${alignedImage} filename="aligned-image-8k.jpeg" class="btn-download" disabled=${!alignedImage || isLoading}>
                            <${DiamondIcon} /> TẢI ẢNH 8K SẮC NÉT
                        </${EnhancedDownloadButton}>
                        <button class="btn" onClick=${() => handleUpscale('4k')} disabled=${!alignedImage || isLoading}>
                             ${isUpscaling === '4k' ? 'Đang nâng cấp...' : 'Xem trước 4K'}
                        </button>
                        <button class="btn" onClick=${() => handleUpscale('8k')} disabled=${!alignedImage || isLoading}>
                             ${isUpscaling === '8k' ? 'Đang nâng cấp...' : 'Xem trước 8K'}
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `;
};