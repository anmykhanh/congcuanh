/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { h, FunctionalComponent } from 'preact';
import { useState, useMemo } from 'preact/hooks';
import htm from 'htm';
import type { TargetedEvent } from 'preact/compat';
import { PresetColorSettings } from '../../types';
import { COLOR_PRESETS } from '../../constants';
// FIX: Replaced non-existent `HighQualityDownloadButton` with `EnhancedDownloadButton`.
import { Loader, ImageUploader, ImageComparisonSlider, ImageIcon, EnhancedDownloadButton, DiamondIcon, ImageActionsToolbar } from '../../components';
import { PresetColorSettingsPanel } from './PresetColorSettingsPanel';
import { applyColorPreset } from '../../api';

const html = htm.bind(h);

export const PresetColorApp: FunctionalComponent = () => {
    const [originalImage, setOriginalImage] = useState<string | null>(null);
    const [generatedImage, setGeneratedImage] = useState<string | null>(null);
    const [generating, setGenerating] = useState(false);
    const [error, setError] = useState('');
    const [settings, setSettings] = useState<PresetColorSettings>({
        selectedPreset: null,
        customPrompt: '',
    });
    
    const handleImageUpload = (dataUrl: string | null) => {
        setOriginalImage(dataUrl);
        setGeneratedImage(null);
        setError('');
        // Deselect preset when a new image is uploaded
        setSettings({ selectedPreset: null, customPrompt: '' });
    };

    const handleGenerate = async () => {
        if (!originalImage) return;

        let promptToUse = '';
        if (settings.customPrompt.trim()) {
            promptToUse = settings.customPrompt.trim();
        } else if (settings.selectedPreset) {
            const preset = COLOR_PRESETS.find(p => p.id === settings.selectedPreset);
            if (preset) {
                promptToUse = preset.prompt;
            }
        }

        if (!promptToUse) {
            setError("Vui lòng chọn một preset hoặc nhập mô tả tùy chỉnh.");
            return;
        }

        setGenerating(true);
        setError('');
        try {
            // Use original image for subsequent generations from the same upload
            const imageToProcess = originalImage;
            const result = await applyColorPreset(imageToProcess, promptToUse);
            setGeneratedImage(result);
        } catch (err) {
            if (err instanceof Error) {
                setError(err.message);
            } else {
                setError(String(err));
            }
        } finally {
            setGenerating(false);
        }
    };

    return html`
        <div class="editor-layout">
            <${PresetColorSettingsPanel}
                settings=${settings}
                setSettings=${setSettings}
                onGenerate=${handleGenerate}
                generating=${generating}
                hasImage=${!!originalImage}
            />
            <div class="image-panel">
                ${!originalImage ? html`
                    <${ImageUploader} onImageUpload=${(img: string) => handleImageUpload(img)} id="preset-uploader" />
                ` : html`
                    <div class="image-panel-preview">
                        ${generating && html`<${Loader} text="AI đang áp dụng preset màu..." />`}
                        <div class="image-display-wrapper">
                            <${ImageComparisonSlider} original=${originalImage} generated=${generatedImage} objectFit="contain" />
                            <${ImageActionsToolbar}
                                generatedImage=${generatedImage}
                                filename=${`preset-${settings.selectedPreset || 'custom'}.jpeg`}
                                onReset=${() => handleImageUpload(null)}
                                isGenerating=${generating}
                            />
                        </div>
                        ${error && html`<div class="error-message">${error}</div>`}
                    </div>
                `}
            </div>
        </div>
    `;
};