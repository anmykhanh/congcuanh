/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { h, FunctionalComponent } from 'preact';
import type { TargetedEvent } from 'preact/compat';
import htm from 'htm';
import { PresetColorSettings } from '../../types';
import { COLOR_PRESETS } from '../../constants';
import { UploadIcon, PaletteIcon } from '../../components';

const html = htm.bind(h);

interface PresetColorSettingsPanelProps {
    settings: PresetColorSettings;
    setSettings: (updater: (s: PresetColorSettings) => PresetColorSettings) => void;
    onGenerate: () => void;
    generating: boolean;
    hasImage: boolean;
}

export const PresetColorSettingsPanel: FunctionalComponent<PresetColorSettingsPanelProps> = ({
    settings,
    setSettings,
    onGenerate,
    generating,
    hasImage,
}) => {
    const handlePresetSelect = (presetId: string) => {
        // Deselect custom prompt when a preset is chosen
        setSettings(s => ({ ...s, selectedPreset: presetId, customPrompt: '' }));
    };

    const handleCustomPromptInput = (e: TargetedEvent<HTMLTextAreaElement>) => {
        const value = e.currentTarget.value;
        // Deselect preset when a custom prompt is entered
        setSettings(s => ({ ...s, customPrompt: value, selectedPreset: null }));
    };

    const AccordionSection: FunctionalComponent<{ title: string, step: number, disabled?: boolean, children?: any }> = ({ title, step, disabled = false, children }) => {
        const isCollapsed = true; // For now, it's always collapsed and shows the disabled message.
        return html`
            <div class="form-section">
                <h3 class="form-section-title" style=${{ 
                    display: 'flex', 
                    alignItems: 'center', 
                    justifyContent: 'space-between',
                    opacity: disabled ? 0.5 : 1,
                    cursor: disabled ? 'default' : 'pointer'
                }}>
                    <span>${step}. ${title}</span>
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor" style=${{ transform: isCollapsed ? 'rotate(0deg)' : 'rotate(90deg)'}}>
                        <path d="M8.59,16.34l4.58-4.59L8.59,7.16L10,5.75l6,6l-6,6L8.59,16.34z"/>
                    </svg>
                </h3>
                ${!isCollapsed && children}
                ${isCollapsed && disabled && html`
                     <div class="disabled-section-placeholder">
                        Chọn một preset để bắt đầu điều chỉnh.
                     </div>
                `}
            </div>
        `;
    }

    return html`
        <div class="settings-panel">
             <div class="form-section">
                <h3 class="form-section-title">1. Tải Ảnh Lên</h3>
                 ${!hasImage ? html`
                    <p class="settings-description" style=${{color: 'var(--text-secondary)', fontSize: '0.9rem', margin: '0.5rem 0'}}>Tải ảnh lên ở khung bên phải để bắt đầu.</p>
                 ` : html `
                    <button class="btn btn-secondary" onClick=${() => document.getElementById('preset-change-image-input')?.click()} style=${{width: '100%'}}>
                        <${UploadIcon} /> Chọn ảnh khác
                    </button>
                 `}
            </div>

            <div class="form-section">
                <h3 class="form-section-title" style=${{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                    <${PaletteIcon} />
                    <span>2. Chọn preset màu</span>
                </h3>
                <div class="lighting-styles-grid">
                    ${COLOR_PRESETS.map(preset => html`
                        <button
                            class="style-button ${settings.selectedPreset === preset.id ? 'active' : ''}"
                            onClick=${() => handlePresetSelect(preset.id)}
                            disabled=${!hasImage || generating}
                        >
                            ${preset.name}
                        </button>
                    `)}
                </div>
            </div>

            <div class="form-section">
                <h3 class="form-section-title">3. Hoặc Tự Tùy Chỉnh Màu</h3>
                <p class="settings-description" style=${{color: 'var(--text-secondary)', fontSize: '0.9rem', margin: '0.5rem 0 0.25rem'}}>
                    Mô tả phong cách màu bạn muốn. AI sẽ giữ nguyên chi tiết ảnh và chỉ thay đổi màu sắc.
                </p>
                <p class="settings-description" style=${{color: 'var(--text-secondary)', fontSize: '0.9rem', margin: '0 0 1rem'}}>
                    <strong>Ví dụ:</strong> "Áp dụng tông màu lạnh, tương phản cao theo phong cách điện ảnh."
                </p>
                <textarea
                    value=${settings.customPrompt}
                    onInput=${handleCustomPromptInput}
                    placeholder="Nhập mô tả màu của bạn ở đây..."
                    rows="4"
                    disabled=${!hasImage || generating}
                />
            </div>

            <button 
                class="btn btn-primary" 
                onClick=${onGenerate} 
                disabled=${generating || !hasImage || (!settings.selectedPreset && !settings.customPrompt.trim())}
                style=${{width: '100%', marginTop: '1rem', padding: '0.85rem'}}
            >
                ${generating ? 'Đang xử lý...' : 'Áp Dụng Hiệu Ứng'}
            </button>
        </div>
    `;
};