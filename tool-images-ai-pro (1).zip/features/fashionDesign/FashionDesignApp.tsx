/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { h, FunctionalComponent } from 'preact';
import { useState } from 'preact/hooks';
import htm from 'htm';
import { FashionDesignSettings } from '../../types';
import { InputPanel, SettingsPanel, ResultsPanel } from './FashionPanels';
import { generateFashionDesign } from '../../api';

const html = htm.bind(h);

export const FashionDesignApp: FunctionalComponent = () => {
    const [modelImage, setModelImage] = useState<string | null>(null);
    const [outfitImage, setOutfitImage] = useState<string | null>(null);
    const [generatedImages, setGeneratedImages] = useState<string[]>([]);
    const [generating, setGenerating] = useState(false);
    const [error, setError] = useState('');
    const [settings, setSettings] = useState<FashionDesignSettings>({
        aspectRatio: '9:16',
        prompt: '',
        cameraAngle: 'Mặc định',
        style: 'Mặc định',
        colorPalette: 'Mặc định',
        lighting: 'Mặc định',
        skinTone: 'Mặc định',
        lens: 'Mặc định',
        seed: String(Math.floor(Math.random() * 100000)),
        numVariants: 4,
    });

    const handleGenerate = async () => {
        if (!modelImage || !outfitImage) {
            setError('Vui lòng tải lên cả ảnh người mẫu và ảnh trang phục.');
            return;
        }
        setGenerating(true);
        setError('');
        setGeneratedImages([]);

        const promises = [];
        let baseSeed = parseInt(settings.seed, 10);
        if (isNaN(baseSeed)) {
            baseSeed = Math.floor(Math.random() * 100000);
        }

        for (let i = 0; i < settings.numVariants; i++) {
            const variantSettings = { ...settings, seed: String(baseSeed + i) };
            promises.push(generateFashionDesign(modelImage, outfitImage, variantSettings));
        }

        try {
            const results = await Promise.all(promises);
            setGeneratedImages(results);
        } catch (err) {
            setError(err instanceof Error ? err.message : 'Đã xảy ra lỗi không mong muốn.');
        } finally {
            setGenerating(false);
        }
    };

    const handleSeparate = () => {
        alert('Tính năng Tách Trang phục sẽ sớm được cập nhật!');
    };

    return html`
        <div class="fashion-layout">
            <${InputPanel}
                modelImage=${modelImage}
                setModelImage=${setModelImage}
                outfitImage=${outfitImage}
                setOutfitImage=${setOutfitImage}
                onGenerate=${handleGenerate}
                onSeparate=${handleSeparate}
                generating=${generating}
                canGenerate=${!!modelImage && !!outfitImage}
            />
            <${SettingsPanel}
                settings=${settings}
                setSettings=${setSettings}
            />
            <${ResultsPanel}
                generatedImages=${generatedImages}
                generating=${generating}
                error=${error}
            />
        </div>
    `;
};