/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { h, FunctionalComponent } from 'preact';
// FIX: Replaced StateUpdater with its full type definition to fix "not callable" errors.
// import { StateUpdater } from 'preact/hooks';
import htm from 'htm';
import { FashionDesignSettings } from '../../types';
import { UploadIcon, CloseIcon, Loader, ImageIcon, UserSolidIcon, ControlsIcon, GridIcon } from '../../components';
import type { TargetedEvent } from 'preact/compat';

const html = htm.bind(h);

interface InputPanelProps {
    modelImage: string | null;
    setModelImage: (value: string | null | ((prevState: string | null) => string | null)) => void;
    outfitImage: string | null;
    setOutfitImage: (value: string | null | ((prevState: string | null) => string | null)) => void;
    onGenerate: () => void;
    onSeparate: () => void;
    generating: boolean;
    canGenerate: boolean;
}

const ImageUploadBox: FunctionalComponent<{
    image: string | null;
    onImageUpload: (dataUrl: string) => void;
    onImageRemove: () => void;
    id: string;
    children: any;
}> = ({ image, onImageUpload, onImageRemove, id, children }) => {
    
    const handleFileChange = (e: TargetedEvent<HTMLInputElement>) => {
        const file = e.currentTarget.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (e) => onImageUpload(e.target?.result as string);
            reader.readAsDataURL(file);
        }
    };

    return html`
        <div class="upload-box-fashion" onClick=${() => document.getElementById(id)?.click()}>
            <input type="file" id=${id} accept="image/*" style=${{display: 'none'}} onChange=${handleFileChange} />
            ${image ? html`
                <img src=${image} alt="Uploaded preview" />
                <button class="remove-reference-btn" onClick=${(e: MouseEvent) => { e.stopPropagation(); onImageRemove(); }}><${CloseIcon} /></button>
            ` : children}
        </div>
    `;
};

export const InputPanel: FunctionalComponent<InputPanelProps> = ({ modelImage, setModelImage, outfitImage, setOutfitImage, onGenerate, onSeparate, generating, canGenerate }) => {
    return html`
        <aside class="fashion-panel">
            <div class="panel-header">
                <strong>BUOC 1</strong>
                <${UserSolidIcon} />
                <span class="panel-title">Không gian Dàn dựng & Tủ đồ</span>
            </div>
            <div class="panel-content">
                <div class="input-card">
                    <span class="card-label"><span class="step-circle">1</span>Người mẫu & Trang phục gốc</span>
                    <${ImageUploadBox} 
                        image=${modelImage} 
                        onImageUpload=${(url: string) => setModelImage(url)} 
                        onImageRemove=${() => setModelImage(null)}
                        id="model-upload"
                    >
                        <${UploadIcon} />
                        <span>Tải ảnh lên</span>
                    </${ImageUploadBox}>
                </div>
                <div class="input-card">
                    <span class="card-label"><span class="step-circle">2</span>Trang phục đã tách</span>
                     <${ImageUploadBox} 
                        image=${outfitImage} 
                        onImageUpload=${(url: string) => setOutfitImage(url)} 
                        onImageRemove=${() => setOutfitImage(null)}
                        id="outfit-upload"
                    >
                        <${UploadIcon} />
                        <span>Tải ảnh lên</span>
                    </${ImageUploadBox}>
                </div>
                 <button class="btn btn-primary" onClick=${onSeparate}>Tách Trang phục</button>
                 <div class="input-card">
                    <span class="card-label"><span class="step-circle">3</span>Người mẫu mới & Dáng điệu</span>
                     <div class="upload-box-fashion" style="justify-content: center; text-align: center; color: #888;">
                        <${UploadIcon} />
                        <span>(Tính năng sắp ra mắt)</span>
                    </div>
                </div>
                 <button class="btn btn-primary" onClick=${onGenerate} disabled=${generating || !canGenerate}>
                    ${generating ? 'Đang tạo...' : 'Thử đồ cho Người mẫu Mới'}
                 </button>
            </div>
        </aside>
    `;
};

interface SettingsPanelProps {
    settings: FashionDesignSettings;
    setSettings: (value: FashionDesignSettings | ((prevState: FashionDesignSettings) => FashionDesignSettings)) => void;
}

const DropdownControl: FunctionalComponent<{label: string, value: string, options: string[], onChange: (e: TargetedEvent<HTMLSelectElement>) => void}> = ({ label, value, options, onChange }) => html`
    <div class="form-group">
        <label>${label}</label>
        <select value=${value} onChange=${onChange}>
            ${options.map(opt => html`<option value=${opt}>${opt}</option>`)}
        </select>
    </div>
`;


export const SettingsPanel: FunctionalComponent<SettingsPanelProps> = ({ settings, setSettings }) => {
    const handleSettingChange = (field: keyof FashionDesignSettings) => (e: TargetedEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
        setSettings(s => ({ ...s, [field]: e.currentTarget.value }));
    };

    const handleNumVariants = (delta: number) => {
        setSettings(s => ({ ...s, numVariants: Math.max(1, Math.min(8, s.numVariants + delta)) }));
    };

    return html`
        <main class="fashion-panel">
            <div class="panel-header">
                 <strong>BUOC 2</strong>
                <span class="panel-title">Bảng điều khiển Sáng tạo</span>
            </div>
            <div class="panel-content">
                <div class="settings-panel">
                     <div class="fashion-settings-header">
                        <div class="form-group">
                            <label>Tỉ lệ ảnh</label>
                            <div class="toggle-group">
                                <button class="toggle-btn ${settings.aspectRatio === '9:16' ? 'active' : ''}" onClick=${() => setSettings(s => ({...s, aspectRatio: '9:16'}))}>9:16</button>
                                <button class="toggle-btn ${settings.aspectRatio === '16:9' ? 'active' : ''}" onClick=${() => setSettings(s => ({...s, aspectRatio: '16:9'}))}>16:9</button>
                            </div>
                        </div>
                        <div class="form-group">
                             <label>Dịch vụ AI</label>
                             <select><option>Fircode Gemini</option></select>
                        </div>
                    </div>
                    
                    <div class="form-section">
                        <h4 class="form-section-title">Thiết lập Nâng cao</h4>
                        <div class="form-group">
                            <label>Mô tả Ý tưởng chính</label>
                            <textarea rows="3" placeholder="VD: Một người mẫu high-fashion trong bộ trang phục avant-garde..." value=${settings.prompt} onInput=${handleSettingChange('prompt')}></textarea>
                        </div>

                        <${DropdownControl} label="Góc máy" value=${settings.cameraAngle} options=${['Mặc định', 'Cận cảnh', 'Toàn thân', 'Góc rộng']} onChange=${handleSettingChange('cameraAngle')} />
                        <${DropdownControl} label="Phong cách" value=${settings.style} options=${['Mặc định', 'Hiện thực', 'Điện ảnh', 'Tranh vẽ']} onChange=${handleSettingChange('style')} />

                        <div class="form-group">
                            <label>Hệ thống kiểm tra</label>
                            <div class="control-buttons-group">
                                <button class="btn btn-primary">Ảnh tham chiếu</button>
                                <button class="btn btn-primary">Trang phục</button>
                                <button class="btn btn-primary">Concept AI</button>
                            </div>
                        </div>

                        <div class="form-group-row">
                            <div class="form-group">
                                <label>Seed</label>
                                <input type="text" value=${settings.seed} onInput=${handleSettingChange('seed')} />
                            </div>
                            <div class="form-group">
                                <label>Số lượng biến thể</label>
                                <div style="display: flex; align-items: center;">
                                    <button class="btn" onClick=${() => handleNumVariants(-1)} style=${{background: '#1E2230', border:'1px solid #3A416F'}}>-</button>
                                    <input type="number" class="number-input" style="text-align: center; borderLeft: none; borderRight: none;" value=${settings.numVariants} onInput=${(e: TargetedEvent<HTMLInputElement>) => setSettings(s => ({...s, numVariants: parseInt(e.currentTarget.value, 10)}))} />
                                    <button class="btn" onClick=${() => handleNumVariants(1)} style=${{background: '#1E2230', border:'1px solid #3A416F'}}>+</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-section">
                        <h4 class="form-section-title">Gợi ý từ AI Art Director</h4>
                        <${DropdownControl} label="Bảng màu" value=${settings.colorPalette} options=${['Mặc định', 'Tông ấm', 'Tông lạnh', 'Đơn sắc']} onChange=${handleSettingChange('colorPalette')} />
                        <${DropdownControl} label="Ánh sáng" value=${settings.lighting} options=${['Mặc định', 'Studio', 'Tự nhiên', 'Kịch tính']} onChange=${handleSettingChange('lighting')} />
                        <${DropdownControl} label="Tông da" value=${settings.skinTone} options=${['Mặc định', 'Tự nhiên', 'Sáng', 'Tối']} onChange=${handleSettingChange('skinTone')} />
                        <${DropdownControl} label="Ống kính" value=${settings.lens} options=${['Mặc định', '35mm', '50mm', '85mm']} onChange=${handleSettingChange('lens')} />
                    </div>
                </div>
            </div>
        </main>
    `;
};


interface ResultsPanelProps {
    generatedImages: string[];
    generating: boolean;
    error: string;
}

export const ResultsPanel: FunctionalComponent<ResultsPanelProps> = ({ generatedImages, generating, error }) => {
    return html`
        <aside class="fashion-panel">
             <div class="panel-header">
                <strong>BUOC 3</strong>
                <span class="panel-title">Thư viện Kết quả</span>
            </div>
            <div class="results-panel-content">
                <div class="results-actions-header">
                    <span>Thao tác Hàng loạt</span>
                    <div class="select-all-checkbox">
                        <button>Chọn tất cả Ảnh</button>
                        <input type="checkbox" />
                    </div>
                </div>

                <div class="tabs" style="margin-bottom: 1rem; border-color: var(--fashion-border);">
                    <button class="tab active">Ảnh (${generatedImages.length})</button>
                    <button class="tab">Video</button>
                </div>
                <div class="results-grid-fashion">
                    ${generating && html`<${Loader} text="Đang tạo..." />`}
                    ${!generating && error && html`<div class="error-message">${error}</div>`}
                    ${!generating && generatedImages.length === 0 && !error && html`
                        <div class="placeholder-container" style="height: 100%; color: #888;">
                            <${ImageIcon} class="placeholder-icon" />
                            <p>Kết quả sẽ hiện ở đây.</p>
                        </div>
                    `}
                    ${generatedImages.map(url => html`
                        <div class="result-image-wrapper">
                            <img src=${url} alt="Generated fashion design" />
                        </div>
                    `)}
                </div>
            </div>
        </aside>
    `;
};