/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { h, FunctionalComponent } from 'preact';
import { useState } from 'preact/hooks';
import htm from 'htm';
import type { TargetedEvent } from 'preact/compat';
import { DocumentRestorationSettings, CommonSettingsPanelProps } from '../../types';
import { describeDocumentForRestoration } from '../../api';

const html = htm.bind(h);

interface DocumentRestorationSettingsPanelProps extends CommonSettingsPanelProps {
    settings: DocumentRestorationSettings;
    setSettings: (updater: (s: DocumentRestorationSettings) => DocumentRestorationSettings) => void;
    originalImage?: string | null;
}

export const DocumentRestorationSettingsPanel: FunctionalComponent<DocumentRestorationSettingsPanelProps> = ({ settings, setSettings, onGenerate, generating, hasImage, originalImage }) => {
    const [isAnalyzing, setIsAnalyzing] = useState(false);
    const [analysisError, setAnalysisError] = useState('');

    const handleCreateDescription = async () => {
        if (!originalImage || isAnalyzing || generating) return;
        setIsAnalyzing(true);
        setAnalysisError('');
        try {
            const description = await describeDocumentForRestoration(originalImage);
            setSettings(s => ({ ...s, customPrompt: description }));
        } catch (err) {
            setAnalysisError(err instanceof Error ? err.message : 'Lỗi tạo mô tả.');
        } finally {
            setIsAnalyzing(false);
        }
    };
    
    const handleCheckboxChange = (e: TargetedEvent<HTMLInputElement>) => {
        const { name, checked } = e.currentTarget;
        setSettings(s => ({ ...s, [name]: checked }));
    };

    return html`
        <div class="settings-panel">
            <div class="form-section">
                <h3 class="form-section-title">Công cụ AI</h3>
                 <div style=${{ display: 'flex', gap: '0.5rem' }}>
                    <button
                        class="btn btn-secondary"
                        style=${{ flex: 1 }}
                        onClick=${handleCreateDescription}
                        disabled=${!originalImage || isAnalyzing || generating}
                    >
                        ${isAnalyzing ? 'Đang tạo...' : 'Tạo Mô Tả'}
                    </button>
                </div>
                ${analysisError && html`<div class="error-message" style="margin-top: 1rem; text-align: left;">${analysisError}</div>`}
            </div>
            
            <div class="form-section">
                <h3 class="form-section-title">Tùy chọn phục hồi</h3>
                <div class="checkbox-grid-restoration" style=${{gridTemplateColumns: '1fr'}}>
                    <label><input type="checkbox" name="straighten" checked=${settings.straighten} onChange=${handleCheckboxChange} /> Duỗi thẳng & Căn góc</label>
                    <label><input type="checkbox" name="removeStains" checked=${settings.removeStains} onChange=${handleCheckboxChange} /> Xóa vết bẩn, ố, mốc</label>
                    <label><input type="checkbox" name="flattenCreases" checked=${settings.flattenCreases} onChange=${handleCheckboxChange} /> Làm phẳng nếp gấp, vết rách</label>
                    <label><input type="checkbox" name="enhanceText" checked=${settings.enhanceText} onChange=${handleCheckboxChange} /> Làm rõ chữ viết & dấu mộc</label>
                    <label><input type="checkbox" name="restoreColors" checked=${settings.restoreColors} onChange=${handleCheckboxChange} /> Phục hồi màu sắc (nếu có)</label>
                </div>
            </div>

            <div class="form-group">
                <label class="form-section-label">Phong cách đầu ra</label>
                <div class="toggle-group">
                    <button 
                        class="toggle-btn ${settings.outputStyle === 'new' ? 'active' : ''}"
                        onClick=${() => setSettings(s => ({...s, outputStyle: 'new'}))}
                    >
                        Làm như mới
                    </button>
                    <button 
                        class="toggle-btn ${settings.outputStyle === 'vintage' ? 'active' : ''}"
                        onClick=${() => setSettings(s => ({...s, outputStyle: 'vintage'}))}
                    >
                        Giữ vẻ cổ điển
                    </button>
                    <button 
                        class="toggle-btn ${settings.outputStyle === 'preserve' ? 'active' : ''}"
                        onClick=${() => setSettings(s => ({...s, outputStyle: 'preserve'}))}
                    >
                        Giữ nguyên vẹn từng chi tiết ảnh
                    </button>
                </div>
            </div>

            <div class="form-group">
                <label for="custom-prompt-doc">Yêu cầu tùy chỉnh (Tùy chọn)</label>
                <textarea 
                    id="custom-prompt-doc" 
                    placeholder="Ví dụ: Giữ lại con dấu màu đỏ ở góc trái..."
                    value=${settings.customPrompt}
                    onInput=${(e: TargetedEvent<HTMLTextAreaElement>) => setSettings(s => ({ ...s, customPrompt: e.currentTarget.value }))}
                ></textarea>
            </div>
            
            <button class="btn btn-primary" onClick=${onGenerate} disabled=${generating || !hasImage} style=${{width: '100%', marginTop: '0.5rem', padding: '0.85rem'}}>
                ${generating ? 'Đang phục hồi...' : 'PHỤC HỒI GIẤY TỜ'}
            </button>
        </div>
    `;
};