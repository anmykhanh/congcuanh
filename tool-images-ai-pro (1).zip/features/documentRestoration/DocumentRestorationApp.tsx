/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { h, FunctionalComponent } from 'preact';
import { useState } from 'preact/hooks';
import htm from 'htm';
import { DocumentRestorationSettings } from '../../types';
import { Loader, ImageUploader, ImageComparisonSlider, ImageActionsToolbar } from '../../components';
import { DocumentRestorationSettingsPanel } from './DocumentRestorationSettingsPanel';
import { restoreDocument } from '../../api';
import { addHistoryItem } from '../../history';
import { TABS } from '../../constants';

const html = htm.bind(h);

const initialSettings: DocumentRestorationSettings = {
    removeStains: true,
    flattenCreases: true,
    enhanceText: true,
    restoreColors: true,
    outputStyle: 'new',
    straighten: true,
    customPrompt: '',
};

export const DocumentRestorationApp: FunctionalComponent = () => {
    const [originalImage, setOriginalImage] = useState<string | null>(null);
    const [generatedImage, setGeneratedImage] = useState<string | null>(null);
    const [generating, setGenerating] = useState(false);
    const [error, setError] = useState('');
    const [settings, setSettings] = useState<DocumentRestorationSettings>(initialSettings);

    const handleGenerate = async () => {
        if (!originalImage) return;
        setGenerating(true);
        setError('');
        try {
            const result = await restoreDocument(originalImage, settings);
            setGeneratedImage(result);
            const featureInfo = TABS.find(t => t.id === 'document-restoration');
            await addHistoryItem({
                original: originalImage,
                generated: result,
                feature: 'document-restoration',
                featureLabel: featureInfo?.label || 'Phục Hồi Giấy Tờ Cũ',
            });
        } catch (err) {
            if (err instanceof Error) {
                setError(err.message);
            } else {
                setError(String(err));
            }
        } finally {
            setGenerating(false);
        }
    };
    
    const handleUpload = (image: string | null) => {
        setOriginalImage(image);
        setGeneratedImage(null);
        setError('');
    }
    
    return html`
        <div class="editor-layout">
            <${DocumentRestorationSettingsPanel} 
                settings=${settings} 
                setSettings=${setSettings} 
                onGenerate=${handleGenerate} 
                generating=${generating} 
                hasImage=${!!originalImage} 
                originalImage=${originalImage}
            />
            <div class="image-panel">
                ${!originalImage ? html`
                    <${ImageUploader} onImageUpload=${(img: string) => handleUpload(img)} />
                ` : html`
                    <div class="image-panel-preview">
                        ${generating && html`<${Loader} text="AI đang phục hồi giấy tờ..." />`}
                        <div class="image-display-wrapper">
                            <${ImageComparisonSlider} original=${originalImage} generated=${generatedImage} objectFit="contain" />
                            <${ImageActionsToolbar}
                                generatedImage=${generatedImage}
                                filename="restored-document.jpeg"
                                onReset=${() => handleUpload(null)}
                                isGenerating=${generating}
                            />
                        </div>
                        ${error && html`<div class="error-message">${error}</div>`}
                    </div>
                `}
            </div>
        </div>
    `;
};