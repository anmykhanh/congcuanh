/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { h, FunctionalComponent } from 'preact';
import { useRef } from 'preact/hooks';
import htm from 'htm';
import type { TargetedEvent } from 'preact/compat';
import { ColorCorrectionSettings, CommonSettingsPanelProps, HSLColor, HSLAdjustmentType } from '../../types';
import { UploadIcon, DownloadIcon, EnhancedDownloadButton } from '../../components';

const html = htm.bind(h);

interface ColorCorrectionSettingsPanelProps extends CommonSettingsPanelProps {
    settings: ColorCorrectionSettings;
    setSettings: (updater: (s: ColorCorrectionSettings) => ColorCorrectionSettings) => void;
    onAutoAdjust: () => void;
    isAnalyzing: boolean;
    onImageUpload: (dataUrl: string) => void;
    generatedImage: string | null;
}

const HSL_COLORS: { key: HSLColor; name: string; gradients: { hue: string; saturation: string; luminance: string; } }[] = [
    { key: 'reds', name: 'Đỏ', gradients: { hue: 'linear-gradient(to right, #ff00ff, #ff0000, #ff7f00)', saturation: 'linear-gradient(to right, #808080, #ff0000)', luminance: 'linear-gradient(to right, #000, #ff0000, #fff)' } },
    { key: 'oranges', name: 'Cam', gradients: { hue: 'linear-gradient(to right, #ff0000, #ff7f00, #ffff00)', saturation: 'linear-gradient(to right, #808080, #ff7f00)', luminance: 'linear-gradient(to right, #000, #ff7f00, #fff)' } },
    { key: 'yellows', name: 'Vàng', gradients: { hue: 'linear-gradient(to right, #ff7f00, #ffff00, #7fff00)', saturation: 'linear-gradient(to right, #808080, #ffff00)', luminance: 'linear-gradient(to right, #000, #ffff00, #fff)' } },
    { key: 'greens', name: 'Lục', gradients: { hue: 'linear-gradient(to right, #ffff00, #00ff00, #00ffff)', saturation: 'linear-gradient(to right, #808080, #00ff00)', luminance: 'linear-gradient(to right, #000, #00ff00, #fff)' } },
    { key: 'aquas', name: 'Lam', gradients: { hue: 'linear-gradient(to right, #00ff00, #00ffff, #0000ff)', saturation: 'linear-gradient(to right, #808080, #00ffff)', luminance: 'linear-gradient(to right, #000, #00ffff, #fff)' } },
    { key: 'blues', name: 'Xanh', gradients: { hue: 'linear-gradient(to right, #00ffff, #0000ff, #ff00ff)', saturation: 'linear-gradient(to right, #808080, #0000ff)', luminance: 'linear-gradient(to right, #000, #0000ff, #fff)' } },
    { key: 'purples', name: 'Tím', gradients: { hue: 'linear-gradient(to right, #0000ff, #800080, #ff00ff)', saturation: 'linear-gradient(to right, #808080, #800080)', luminance: 'linear-gradient(to right, #000, #800080, #fff)' } },
    { key: 'magentas', name: 'Hồng', gradients: { hue: 'linear-gradient(to right, #800080, #ff00ff, #ff0000)', saturation: 'linear-gradient(to right, #808080, #ff00ff)', luminance: 'linear-gradient(to right, #000, #ff00ff, #fff)' } },
];


export const ColorCorrectionSettingsPanel: FunctionalComponent<ColorCorrectionSettingsPanelProps> = ({ settings, setSettings, onGenerate, generating, hasImage, onAutoAdjust, isAnalyzing, onImageUpload, generatedImage }) => {
    
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleFileChange = (e: TargetedEvent<HTMLInputElement>) => {
        const file = e.currentTarget.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (loadEvent) => {
                if (loadEvent.target?.result) {
                    onImageUpload(loadEvent.target.result as string);
                }
            };
            reader.readAsDataURL(file);
        }
        // Reset file input to allow uploading the same file again
        if(e.currentTarget) e.currentTarget.value = '';
    };

    const LightSliderControl = ({ label, settingKey, min, max, value }: { label: string, settingKey: keyof ColorCorrectionSettings, min: number, max: number, value: number }) => html`
        <div class="slider-control">
            <div class="slider-label">
                <span>${label}</span>
                <span class="value">${value}</span>
            </div>
            <input 
                type="range" 
                min=${min} 
                max=${max} 
                value=${value} 
                onInput=${(e: TargetedEvent<HTMLInputElement>) => setSettings(s => ({...s, [settingKey]: parseInt(e.currentTarget.value, 10)}))}
                disabled=${!hasImage || generating || isAnalyzing}
            />
        </div>
    `;

    const ColorSliderControl = ({ label, value, gradient, onInput }: { label: string; value: number; gradient: string; onInput: (e: TargetedEvent<HTMLInputElement>) => void; }) => html`
        <div class="color-slider-item">
            <span class="color-slider-label">${label}</span>
            <div class="color-slider-control">
                <div class="color-slider-track" style=${{ background: gradient }}></div>
                <input
                    type="range"
                    min="-100"
                    max="100"
                    value=${value}
                    onInput=${onInput}
                    disabled=${!hasImage || generating || isAnalyzing}
                />
            </div>
            <span class="color-slider-value">${value}</span>
        </div>
    `;

    const handleHslChange = (type: HSLAdjustmentType, color: HSLColor, value: string) => {
        setSettings(s => ({
            ...s,
            [type]: {
                ...s[type],
                [color]: parseInt(value, 10),
            }
        }));
    };

    const resetSettings = () => {
        setSettings(() => ({
            exposure: 0,
            contrast: 0,
            highlights: 0,
            shadows: 0,
            whites: 0,
            blacks: 0,
            hue: { reds: 0, oranges: 0, yellows: 0, greens: 0, aquas: 0, blues: 0, purples: 0, magentas: 0 },
            saturation: { reds: 0, oranges: 0, yellows: 0, greens: 0, aquas: 0, blues: 0, purples: 0, magentas: 0 },
            luminance: { reds: 0, oranges: 0, yellows: 0, greens: 0, aquas: 0, blues: 0, purples: 0, magentas: 0 },
        }));
    };

    return html`
        <div class="settings-panel color-correction-panel">
             <input type="file" ref=${fileInputRef} onChange=${handleFileChange} accept="image/*" style=${{ display: 'none' }} />
             <div class="form-section">
                <h3 class="form-section-title">Công cụ</h3>
                <div style=${{display: 'flex', flexDirection: 'column', gap: '0.75rem'}}>
                    <button 
                        class="btn btn-secondary" 
                        onClick=${() => fileInputRef.current?.click()}
                        style=${{width: '100%'}}
                        disabled=${generating || isAnalyzing}
                    >
                        <${UploadIcon} /> ${hasImage ? 'Tải ảnh khác' : 'Tải ảnh lên'}
                    </button>
                    <button 
                        class="btn btn-secondary" 
                        onClick=${onAutoAdjust} 
                        disabled=${!hasImage || generating || isAnalyzing}
                        style=${{width: '100%'}}
                    >
                        ${isAnalyzing ? 'Đang phân tích...' : 'Tự động điều chỉnh'}
                    </button>
                </div>
            </div>

            <details class="collapsible-section" open>
                <summary>Ánh sáng</summary>
                <div class="light-sliders">
                    <${LightSliderControl} label="Phơi sáng" settingKey="exposure" min="-100" max="100" value=${settings.exposure} />
                    <${LightSliderControl} label="Tương phản" settingKey="contrast" min="-100" max="100" value=${settings.contrast} />
                    <${LightSliderControl} label="Vùng sáng" settingKey="highlights" min="-100" max="100" value=${settings.highlights} />
                    <${LightSliderControl} label="Vùng tối" settingKey="shadows" min="-100" max="100" value=${settings.shadows} />
                    <${LightSliderControl} label="Điểm trắng" settingKey="whites" min="-100" max="100" value=${settings.whites} />
                    <${LightSliderControl} label="Điểm đen" settingKey="blacks" min="-100" max="100" value=${settings.blacks} />
                </div>
            </details>

            <details class="collapsible-section" open>
                <summary>Màu sắc - HSL</summary>
                <div class="hsl-section">
                    <h4>Tông màu (Hue)</h4>
                    <div class="hsl-sliders">
                        ${HSL_COLORS.map(c => html`
                            <${ColorSliderControl}
                                label=${c.name}
                                value=${settings.hue[c.key]}
                                gradient=${c.gradients.hue}
                                onInput=${(e: TargetedEvent<HTMLInputElement>) => handleHslChange('hue', c.key, e.currentTarget.value)}
                            />
                        `)}
                    </div>
                </div>
                 <div class="hsl-section">
                    <h4>Bão hòa (Saturation)</h4>
                    <div class="hsl-sliders">
                         ${HSL_COLORS.map(c => html`
                            <${ColorSliderControl}
                                label=${c.name}
                                value=${settings.saturation[c.key]}
                                gradient=${c.gradients.saturation}
                                onInput=${(e: TargetedEvent<HTMLInputElement>) => handleHslChange('saturation', c.key, e.currentTarget.value)}
                            />
                        `)}
                    </div>
                </div>
                 <div class="hsl-section">
                    <h4>Độ sáng (Luminance)</h4>
                    <div class="hsl-sliders">
                         ${HSL_COLORS.map(c => html`
                            <${ColorSliderControl}
                                label=${c.name}
                                value=${settings.luminance[c.key]}
                                gradient=${c.gradients.luminance}
                                onInput=${(e: TargetedEvent<HTMLInputElement>) => handleHslChange('luminance', c.key, e.currentTarget.value)}
                            />
                        `)}
                    </div>
                </div>
            </details>

            <div class="form-group-row" style=${{marginTop: 'auto', paddingTop: '1rem', flexWrap: 'wrap', gap: '0.5rem'}}>
                <button 
                    class="btn btn-secondary" 
                    onClick=${resetSettings}
                    disabled=${!hasImage || generating || isAnalyzing}
                    style=${{flex: 1}}
                >
                    Đặt lại
                </button>
                <button 
                    class="btn btn-primary" 
                    onClick=${onGenerate} 
                    disabled=${generating || !hasImage}
                    style=${{flex: 1}}
                >
                    ${generating ? 'Đang áp dụng...' : 'Áp dụng'}
                </button>
                 <${EnhancedDownloadButton}
                    baseImageUrl=${generatedImage}
                    filename="color-corrected.jpeg"
                    disabled=${!generatedImage || generating || isAnalyzing}
                    class="btn-primary"
                    style=${{width: '100%', marginTop: '0.5rem'}}
                >
                    <${DownloadIcon} /> Tải ảnh xuống
                </${EnhancedDownloadButton}>
            </div>
        </div>
    `;
};
