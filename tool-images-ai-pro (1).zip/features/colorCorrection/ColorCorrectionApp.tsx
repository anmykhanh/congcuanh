/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { h, FunctionalComponent } from 'preact';
import { useState } from 'preact/hooks';
import htm from 'htm';

import { ColorCorrectionSettings } from '../../types';
import { Loader, ImageUploader, ImageComparisonSlider, ImageActionsToolbar, ImageIcon } from '../../components';
import { ColorCorrectionSettingsPanel } from './ColorCorrectionSettingsPanel';
import { correctColor, analyzeAndSuggestColorSettings } from '../../api';

const html = htm.bind(h);

const initialSettings: ColorCorrectionSettings = {
    exposure: 0,
    contrast: 0,
    highlights: 0,
    shadows: 0,
    whites: 0,
    blacks: 0,
    hue: { reds: 0, oranges: 0, yellows: 0, greens: 0, aquas: 0, blues: 0, purples: 0, magentas: 0 },
    saturation: { reds: 0, oranges: 0, yellows: 0, greens: 0, aquas: 0, blues: 0, purples: 0, magentas: 0 },
    luminance: { reds: 0, oranges: 0, yellows: 0, greens: 0, aquas: 0, blues: 0, purples: 0, magentas: 0 },
};

export const ColorCorrectionApp: FunctionalComponent = () => {
    const [originalImage, setOriginalImage] = useState<string | null>(null);
    const [generatedImage, setGeneratedImage] = useState<string | null>(null);
    const [generating, setGenerating] = useState(false);
    const [isAnalyzing, setIsAnalyzing] = useState(false);
    const [error, setError] = useState('');
    const [settings, setSettings] = useState<ColorCorrectionSettings>(initialSettings);

    const handleImageUpload = (dataUrl: string | null) => {
        setOriginalImage(dataUrl);
        setGeneratedImage(null);
        setError('');
        // Reset settings on new image
        setSettings(initialSettings);
    };

    const handleGenerate = async () => {
        if (!originalImage) return;

        setGenerating(true);
        setError('');
        try {
            const result = await correctColor(originalImage, settings);
            setGeneratedImage(result);
        } catch (err) {
            setError(err instanceof Error ? err.message : "Đã xảy ra lỗi không xác định.");
        } finally {
            setGenerating(false);
        }
    };
    
    const handleAutoAdjust = async () => {
        if (!originalImage) return;
        setIsAnalyzing(true);
        setError('');
        try {
            const suggestedSettings = await analyzeAndSuggestColorSettings(originalImage);
            setSettings(suggestedSettings);
            // After auto-adjusting sliders, immediately apply the effect for a better UX.
            const result = await correctColor(originalImage, suggestedSettings);
            setGeneratedImage(result);
        } catch (err) {
            setError(err instanceof Error ? err.message : "Lỗi khi tự động điều chỉnh.");
        } finally {
            setIsAnalyzing(false);
        }
    };


    return html`
        <div class="editor-layout">
            <${ColorCorrectionSettingsPanel}
                settings=${settings}
                setSettings=${setSettings}
                onGenerate=${handleGenerate}
                generating=${generating}
                hasImage=${!!originalImage}
                onAutoAdjust=${handleAutoAdjust}
                isAnalyzing=${isAnalyzing}
                onImageUpload=${handleImageUpload}
                generatedImage=${generatedImage}
            />
            <div class="image-panel">
                 ${!originalImage ? html`
                    <div class="image-panel-content">
                        <${ImageIcon} class="placeholder-icon"/>
                        <h4>Căn Chỉnh Màu Sắc</h4>
                        <p class="placeholder-text">Tải ảnh lên và sử dụng thanh trượt để điều chỉnh hoặc để AI tự động làm điều đó cho bạn.</p>
                    </div>
                ` : html`
                    <div class="image-panel-preview">
                        ${(generating || isAnalyzing) && html`<${Loader} text=${generating ? "AI đang chỉnh màu..." : "AI đang phân tích..."} />`}
                        <div class="image-display-wrapper">
                            <${ImageComparisonSlider} original=${originalImage} generated=${generatedImage} objectFit="contain" />
                            <${ImageActionsToolbar}
                                generatedImage=${generatedImage}
                                filename="color-corrected.jpeg"
                                onReset=${() => handleImageUpload(null)}
                                isGenerating=${generating || isAnalyzing}
                            />
                        </div>
                        ${error && html`<div class="error-message">${error}</div>`}
                    </div>
                `}
            </div>
        </div>
    `;
};
