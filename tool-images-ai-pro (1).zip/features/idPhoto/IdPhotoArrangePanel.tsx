/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { h, FunctionalComponent } from 'preact';
// FIX: Replaced StateUpdater with its full type definition to fix "not callable" errors.
// import { StateUpdater } from 'preact/hooks';
import htm from 'htm';
import type { TargetedEvent } from 'preact/compat';
import { DownloadIcon } from '../../components';
import { paperSizes, photoSizes } from './arrangement';

const html = htm.bind(h);

interface IdPhotoArrangePanelProps {
    onQuickCropAndDownload: (size: '3x4' | '4x6') => void;
    onArrange: (layout: '8_3x4' | '5_4x6' | 'mixed') => Promise<void>;
    onDownloadArrangement: () => void;
    onBackToEditor: () => void;
    activeArrangement: string | null;
    isProcessing: boolean;
    canDownloadArrangement: boolean;
    paperSize: string;
    onPaperSizeChange: (size: string) => void;
    onResize: (options: { aspectRatio?: number; width?: number; height?: number }) => void;
    customWidth: number | '';
    setCustomWidth: (value: number | '' | ((prevState: number | '') => number | '')) => void;
    customHeight: number | '';
    setCustomHeight: (value: number | '' | ((prevState: number | '') => number | '')) => void;
    customArrangement: { [key: string]: number };
    onCustomArrangementChange: (size: string, count: number) => void;
    onCustomArrange: () => void;
}

export const IdPhotoArrangePanel: FunctionalComponent<IdPhotoArrangePanelProps> = ({
    onQuickCropAndDownload, onArrange, onDownloadArrangement, onBackToEditor,
    activeArrangement, isProcessing, canDownloadArrangement, paperSize, onPaperSizeChange,
    onResize, customWidth, setCustomWidth, customHeight, setCustomHeight,
    customArrangement, onCustomArrangementChange, onCustomArrange
}) => {
    return html`
        <div class="settings-panel id-photo-settings-panel">
            <div class="form-section">
                <h3 class="form-section-title">CẮT & TẢI NHANH</h3>
                <div class="form-group-row">
                    <button class="btn btn-secondary" style=${{flex: 1}} onClick=${() => onQuickCropAndDownload('3x4')}>
                        <${DownloadIcon} /> Cắt 3x4
                    </button>
                    <button class="btn btn-secondary" style=${{flex: 1}} onClick=${() => onQuickCropAndDownload('4x6')}>
                        <${DownloadIcon} /> Cắt 4x6
                    </button>
                </div>
            </div>

             <div class="form-section">
                <h3 class="form-section-title">RESIZE ẢNH</h3>
                <label class="form-section-label">Cắt theo tỷ lệ</label>
                <div class="option-grid">
                    <button class="option-btn" onClick=${() => onResize({ aspectRatio: 1 })}>Vuông (1:1)</button>
                    <button class="option-btn" onClick=${() => onResize({ aspectRatio: 16/9 })}>Ngang (16:9)</button>
                    <button class="option-btn" onClick=${() => onResize({ aspectRatio: 9/16 })}>Dọc (9:16)</button>
                </div>
                <label class="form-section-label" style=${{marginTop: '1rem'}}>Kích thước tùy chỉnh (px)</label>
                <div class="form-group-row">
                    <input type="number" class="number-input" placeholder="Rộng" value=${customWidth} onInput=${(e: TargetedEvent<HTMLInputElement>) => setCustomWidth(e.currentTarget.value === '' ? '' : parseInt(e.currentTarget.value, 10))} />
                    <input type="number" class="number-input" placeholder="Cao" value=${customHeight} onInput=${(e: TargetedEvent<HTMLInputElement>) => setCustomHeight(e.currentTarget.value === '' ? '' : parseInt(e.currentTarget.value, 10))} />
                </div>
                 <button 
                    class="btn btn-secondary" 
                    style=${{width: '100%', marginTop: '0.5rem'}}
                    onClick=${() => onResize({ width: Number(customWidth), height: Number(customHeight) })}
                    disabled=${!customWidth || !customHeight}
                >Resize</button>
            </div>

            <div class="form-section">
                <div class="form-group">
                    <label for="paper-size" class="form-section-label">Chọn khổ giấy in</label>
                    <select id="paper-size" value=${paperSize} onChange=${(e: TargetedEvent<HTMLSelectElement>) => onPaperSizeChange(e.currentTarget.value)}>
                        ${Object.keys(paperSizes).map(key => html`
                            <option value=${key}>${key.replace(/cm$/, ' cm')}</option>
                        `)}
                    </select>
                </div>
                <h3 class="form-section-title">Sắp xếp ảnh để in (khổ ${paperSize.replace(/cm$/, ' cm')})</h3>
                <div class="option-grid" style=${{gridTemplateColumns: '1fr', gap: '0.5rem'}}>
                    <button 
                        class="option-btn ${activeArrangement === '8_3x4' ? 'active btn-danger' : ''}"
                        onClick=${() => onArrange('8_3x4')}
                        disabled=${isProcessing}
                    >Xếp ảnh 3x4</button>
                    <button 
                        class="option-btn ${activeArrangement === '5_4x6' ? 'active btn-danger' : ''}"
                        onClick=${() => onArrange('5_4x6')}
                        disabled=${isProcessing}
                    >Xếp ảnh 4x6</button>
                    <button 
                        class="option-btn ${activeArrangement === 'mixed' ? 'active btn-danger' : ''}"
                        onClick=${() => onArrange('mixed')}
                        disabled=${isProcessing || paperSize !== '10x15cm'}
                        title=${paperSize !== '10x15cm' ? 'Chỉ dành cho khổ 10x15cm' : ''}
                    >3 ảnh 4x6 + 4 ảnh 3x4</button>
                </div>

                <div style=${{ borderTop: '1px solid var(--border-color)', paddingTop: '1.5rem', marginTop: '1.5rem' }}>
                     <h3 class="form-section-title" style=${{border: 'none', padding: 0, margin: 0}}>Hoặc sắp xếp tùy chọn</h3>
                    <div class="form-group" style=${{ display: 'flex', flexDirection: 'column', gap: '0.75rem', marginTop: '1rem' }}>
                        ${Object.entries(photoSizes).map(([key, size]) => html`
                            <div key=${key} class="form-group-row" style=${{ alignItems: 'center', gap: '0.5rem' }}>
                                <label for=${`custom-count-${key}`} style=${{ flex: 1, margin: 0, fontSize: '0.9rem', color: 'var(--text-secondary)' }}>
                                    Số lượng ảnh ${size.w / 10}x${size.h / 10}cm
                                </label>
                                <input
                                    type="number"
                                    id=${`custom-count-${key}`}
                                    class="number-input"
                                    min="0"
                                    max="50"
                                    value=${customArrangement[key] || 0}
                                    onInput=${(e: TargetedEvent<HTMLInputElement>) => onCustomArrangementChange(key, parseInt(e.currentTarget.value, 10) || 0)}
                                    style=${{ flex: '0 0 70px' }}
                                    disabled=${isProcessing}
                                />
                            </div>
                        `)}
                    </div>
                    <button
                        class=${`btn btn-secondary ${activeArrangement === 'custom' ? 'active btn-danger' : ''}`}
                        style=${{ width: '100%', marginTop: '1rem' }}
                        onClick=${onCustomArrange}
                        disabled=${isProcessing || Object.values(customArrangement).every(c => c === 0)}
                    >
                        ${isProcessing && activeArrangement === 'custom' ? 'Đang tạo...' : 'Tạo bố cục tùy chọn'}
                    </button>
                </div>
            </div>
            
            <button class="btn btn-primary" onClick=${onDownloadArrangement} disabled=${!canDownloadArrangement || isProcessing} style=${{width: '100%', marginTop: '1.5rem', padding: '0.85rem'}}>
                <${DownloadIcon} /> Tải file xuống
            </button>
             <button class="btn btn-secondary" onClick=${onBackToEditor} style=${{width: '100%', marginTop: '0.5rem'}}>
                Quay lại
            </button>
        </div>
    `;
};