
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { h, FunctionalComponent } from 'preact';
import { useState, useRef } from 'preact/hooks';
import htm from 'htm';
import type { TargetedEvent } from 'preact/compat';
import { IdPhotoSettings, CommonSettingsPanelProps } from '../../types';
import {
    GENDER_OPTIONS,
    AGE_GROUP_OPTIONS,
    CLOTHING_OPTIONS,
    HAIR_STYLE_OPTIONS,
    BACKGROUND_COLOR_OPTIONS
} from '../../constants';
import { ImageUploader, UploadIcon, CloseIcon } from '../../components';

const html = htm.bind(h);

interface IdPhotoSettingsPanelProps extends CommonSettingsPanelProps {
    settings: IdPhotoSettings;
    setSettings: (updater: (s: IdPhotoSettings) => IdPhotoSettings) => void;
    originalImage: string | null;
    onImageUpload: (dataUrl: string) => void;
}

export const IdPhotoSettingsPanel: FunctionalComponent<IdPhotoSettingsPanelProps> = ({ settings, setSettings, onGenerate, generating, hasImage, originalImage, onImageUpload }) => {
    const clothingFileInputRef = useRef<HTMLInputElement>(null);

    const handleCustomClothingUpload = (e: TargetedEvent<HTMLInputElement>) => {
        const file = e.currentTarget.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (loadEvent) => {
                if (loadEvent.target) {
                    setSettings(s => ({ 
                        ...s, 
                        customClothingImage: loadEvent.target!.result as string,
                        clothing: '' // Clear predefined clothing prompt
                    }));
                }
            };
            reader.readAsDataURL(file);
        }
    };

    const handleClothingSelect = (option: typeof CLOTHING_OPTIONS[0]) => {
        setSettings(s => ({ 
            ...s, 
            clothing: option.id === 'giu-nguyen' ? '' : option.prompt,
            customClothingImage: null // Clear custom clothing image
        }));
    };
    
    const handleHairSelect = (option: typeof HAIR_STYLE_OPTIONS[0]) => {
        setSettings(s => ({ ...s, hairStyle: option.id === 'giu-nguyen' ? '' : option.prompt }));
    };

    const findActiveClothingId = () => {
        if (!settings.clothing) return 'giu-nguyen';
        const found = CLOTHING_OPTIONS.find(opt => opt.prompt === settings.clothing);
        return found ? found.id : '';
    };

    const findActiveHairId = () => {
        if (!settings.hairStyle) return 'giu-nguyen';
        const found = HAIR_STYLE_OPTIONS.find(opt => opt.prompt === settings.hairStyle);
        return found ? found.id : '';
    };

    return html`
        <div class="settings-panel id-photo-settings-panel">
            <div class="form-section">
                <h3 class="form-section-title">1. Ảnh Gốc</h3>
                ${originalImage ? html`
                    <div class="image-preview-container">
                        <img src=${originalImage} alt="Uploaded preview"/>
                        <button class="btn btn-secondary" onClick=${() => onImageUpload('')} style=${{width: '100%', marginTop:'1rem'}}>
                            Tải ảnh khác
                        </button>
                    </div>
                ` : html`
                     <${ImageUploader} onImageUpload=${onImageUpload} id="id-photo-uploader"/>
                `}
            </div>
            
            <div class="form-section">
                <h3 class="form-section-title">2. Tùy chỉnh ảnh</h3>
                
                <div class="form-group">
                    <label class="form-section-label">Giới tính</label>
                    <div class="toggle-group">
                        ${GENDER_OPTIONS.map(opt => html`
                            <button 
                                class="toggle-btn ${settings.gender === opt.id ? 'active' : ''}"
                                onClick=${() => setSettings(s => ({...s, gender: opt.id as IdPhotoSettings['gender']}))}
                            >
                                ${opt.label}
                            </button>
                        `)}
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-section-label">Đối tượng</label>
                    <div class="toggle-group">
                        ${AGE_GROUP_OPTIONS.map(opt => html`
                            <button 
                                class="toggle-btn ${settings.ageGroup === opt.id ? 'active' : ''}"
                                onClick=${() => setSettings(s => ({...s, ageGroup: opt.id as IdPhotoSettings['ageGroup']}))}
                            >
                                ${opt.label}
                            </button>
                        `)}
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-section-label">Trang phục</label>
                    <div class="option-grid">
                        <input 
                            type="file" 
                            ref=${clothingFileInputRef} 
                            onChange=${handleCustomClothingUpload} 
                            accept="image/*" 
                            style=${{ display: 'none' }} 
                        />
                        <button 
                            class="option-btn custom-upload-btn ${settings.customClothingImage ? 'active' : ''}"
                            onClick=${() => clothingFileInputRef.current?.click()}
                            title="Tải lên trang phục tùy chỉnh"
                        >
                            ${settings.customClothingImage ? html`
                                <img src=${settings.customClothingImage} />
                                <button 
                                    class="remove-reference-btn" 
                                    onClick=${(e: MouseEvent) => { 
                                        e.stopPropagation(); 
                                        setSettings(s => ({ ...s, customClothingImage: null })); 
                                    }}
                                >
                                    <${CloseIcon}/>
                                </button>
                            ` : html`
                                <${UploadIcon} style=${{width: '24px', height: '24px'}} />
                                <span style=${{fontSize: '0.75rem', marginTop: '4px'}}>Tải lên</span>
                            `}
                        </button>

                        ${CLOTHING_OPTIONS.map(opt => html`
                             <button 
                                class="option-btn ${findActiveClothingId() === opt.id && !settings.customClothingImage ? 'active' : ''}"
                                onClick=${() => handleClothingSelect(opt)}
                                title=${opt.label}
                            >
                                ${opt.label}
                            </button>
                        `)}
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-section-label">Kiểu tóc</label>
                    <div class="option-grid">
                        ${HAIR_STYLE_OPTIONS.map(opt => html`
                             <button 
                                class="option-btn ${findActiveHairId() === opt.id ? 'active' : ''}"
                                onClick=${() => handleHairSelect(opt)}
                                title=${opt.label}
                            >
                                ${opt.label}
                            </button>
                        `)}
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-section-label">Màu nền</label>
                    <div class="toggle-group">
                        ${BACKGROUND_COLOR_OPTIONS.map(opt => html`
                            <button 
                                class="toggle-btn ${settings.background === opt.id ? 'active' : ''}"
                                onClick=${() => setSettings(s => ({...s, background: opt.id as IdPhotoSettings['background']}))}
                            >
                                ${opt.label}
                            </button>
                        `)}
                    </div>
                </div>

                <div class="slider-group">
                    <div class="switch-group">
                         <label>Làm đẹp da (mịn da, xóa mụn)</label>
                         <label class="switch">
                            <input type="checkbox" checked=${settings.beautifySkin} onChange=${(e: TargetedEvent<HTMLInputElement>) => setSettings(s => ({...s, beautifySkin: e.currentTarget.checked}))} />
                            <span class="slider-switch"></span>
                        </label>
                    </div>

                     <div class="slider-control">
                        <div class="slider-label">
                            <span>Mức độ làm đẹp</span>
                            <span class="value">${settings.beautifyLevel}%</span>
                        </div>
                        <input type="range" min="0" max="100" value=${settings.beautifyLevel} onInput=${(e: TargetedEvent<HTMLInputElement>) => setSettings(s => ({...s, beautifyLevel: parseInt(e.currentTarget.value, 10)}))}/>
                    </div>

                     <div class="slider-control">
                        <div class="slider-label">
                            <span>Mức độ sáng da</span>
                             <span class="value">${settings.brightnessLevel}%</span>
                        </div>
                        <input type="range" min="0" max="100" value=${settings.brightnessLevel} onInput=${(e: TargetedEvent<HTMLInputElement>) => setSettings(s => ({...s, brightnessLevel: parseInt(e.currentTarget.value, 10)}))}/>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-section-label">Mô tả tùy chỉnh (Tùy chọn)</label>
                    <textarea
                        placeholder="Ví dụ: thêm một nốt ruồi nhỏ dưới mắt trái"
                        value=${settings.customPrompt}
                        onInput=${(e: TargetedEvent<HTMLTextAreaElement>) => setSettings(s => ({ ...s, customPrompt: e.currentTarget.value }))}
                    ></textarea>
                </div>
            </div>


            <button class="btn btn-primary" onClick=${onGenerate} disabled=${generating || !hasImage} style=${{width: '100%', padding: '0.85rem'}}>
                ${generating ? 'Đang xử lý...' : 'Tạo ảnh'}
            </button>
        </div>
    `;
};