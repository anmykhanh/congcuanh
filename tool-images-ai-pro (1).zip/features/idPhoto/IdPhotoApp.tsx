/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { h, FunctionalComponent } from 'preact';
import { useState, useMemo, useRef, useEffect } from 'preact/hooks';
import htm from 'htm';
import type { TargetedEvent } from 'preact/compat';

import { ImageItem, IdPhotoSettings } from '../../types';
import { Loader, ImageComparisonSlider, UploadIcon, RegenerateIcon, DeleteIcon, PassportPhotoIcon, CheckIcon, EnhancedDownloadButton, DownloadIcon, SimpleLightbox, ViewIcon } from '../../components';
import { IdPhotoSettingsPanel } from './IdPhotoSettingsPanel';
import { IdPhotoArrangePanel } from './IdPhotoArrangePanel';
import { generateIdPhoto, upscaleImage } from '../../api';
import { arrangePhotosOnCanvas, cropImage, arrangeMixedLayout, resizeImage, arrangeCustomPhotosOnCanvas } from './arrangement';
import { addHistoryItem } from '../../history';
import { TABS } from '../../constants';

const html = htm.bind(h);

const IdPhotoEditor: FunctionalComponent = () => {
    const [originalImage, setOriginalImage] = useState<string | null>(null);
    const [generatedImage, setGeneratedImage] = useState<string | null>(null);
    const [generating, setGenerating] = useState(false);
    const [error, setError] = useState('');
    const [settings, setSettings] = useState<IdPhotoSettings>({
        gender: 'nu',
        ageGroup: 'thanh-nien',
        clothing: '', // Default to 'Giữ nguyên'
        customClothingImage: null,
        hairStyle: '', // Default to 'Giữ nguyên'
        background: 'xanh',
        beautifySkin: true,
        beautifyLevel: 50,
        brightnessLevel: 50,
        customPrompt: '',
    });

    // New state for different views
    const [view, setView] = useState<'editor' | 'arrange_presets'>('editor');
    
    // State for arrangement & resizing view
    const [arrangedImage, setArrangedImage] = useState<string | null>(null);
    const [resizedImage, setResizedImage] = useState<string | null>(null);
    const [isProcessing, setIsProcessing] = useState(false); // Combined arranging & resizing state
    const [activeArrangement, setActiveArrangement] = useState<string | null>(null);
    const [paperSize, setPaperSize] = useState('10x15cm');
    const [customWidth, setCustomWidth] = useState<number | ''>('');
    const [customHeight, setCustomHeight] = useState<number | ''>('');
    const [customArrangement, setCustomArrangement] = useState<{[key: string]: number}>({
        '2x3cm': 0,
        '3x4cm': 0,
        '4x6cm': 0,
    });
    const [lightboxImage, setLightboxImage] = useState<string | null>(null);


    const handleGenerate = async () => {
        if (!originalImage) return;
        setGenerating(true);
        setError('');
        try {
            const result = await generateIdPhoto(originalImage, settings);
            setGeneratedImage(result);
            const featureInfo = TABS.find(t => t.id === 'id-photo');
            await addHistoryItem({
                original: originalImage,
                generated: result,
                feature: 'id-photo',
                featureLabel: featureInfo?.label || 'Ảnh Thẻ',
            });
        } catch (err) {
            if (err instanceof Error) {
                setError(err.message);
            } else {
                setError(String(err));
            }
        } finally {
            setGenerating(false);
        }
    };
    
    const handleCropAndArrange = () => {
        if (!generatedImage) return;
        setView('arrange_presets');
    }

    const handleArrange = async (layout: '8_3x4' | '5_4x6' | 'mixed') => {
        if (!generatedImage || isProcessing) return;
        setIsProcessing(true);
        setActiveArrangement(layout);
        setError('');
        setArrangedImage(null);
        setResizedImage(null);
        try {
            let result;
            switch(layout) {
                case '8_3x4':
                    result = await arrangePhotosOnCanvas(generatedImage, paperSize, '3x4cm');
                    break;
                case '5_4x6':
                    result = await arrangePhotosOnCanvas(generatedImage, paperSize, '4x6cm');
                    break;
                case 'mixed':
                    result = await arrangeMixedLayout(generatedImage);
                    break;
            }
            setArrangedImage(result);
        } catch (err) {
            setError(err instanceof Error ? err.message : 'Lỗi khi xếp ảnh.');
        } finally {
            setIsProcessing(false);
        }
    };
    
    const handleImageUpload = (dataUrl: string) => {
        setOriginalImage(dataUrl);
        setGeneratedImage(null);
        setArrangedImage(null);
        setResizedImage(null);
        setActiveArrangement(null);
        setError('');
        setView('editor');
    };

    const handleQuickCropAndDownload = async (size: '3x4' | '4x6') => {
        if (!generatedImage) return;
        try {
            const aspectRatio = size === '3x4' ? 3/4 : 4/6;
            const cropped = await cropImage(generatedImage, aspectRatio);
            const link = document.createElement('a');
            link.href = cropped;
            link.download = `id-photo-${size}.jpeg`;
            link.click();
        } catch (err) {
            setError(err instanceof Error ? err.message : `Lỗi khi cắt ảnh ${size}.`);
        }
    };
    
    const handleDownloadFinalImage = () => {
        const imageToDownload = resizedImage || arrangedImage;
        if (!imageToDownload) return;
        
        const link = document.createElement('a');
        link.href = imageToDownload;
        link.download = `processed-image-${Date.now()}.jpeg`;
        link.click();
    };

    const handleBackToEditor = () => {
        setView('editor');
        setArrangedImage(null);
        setResizedImage(null);
        setActiveArrangement(null);
        setCustomWidth('');
        setCustomHeight('');
    };
    
    const handlePaperSizeChange = (newSize: string) => {
        setPaperSize(newSize);
        // Reset arrangement when paper size changes
        setArrangedImage(null);
        setResizedImage(null);
        setActiveArrangement(null);
    };

    const handleResize = async (options: { aspectRatio?: number; width?: number; height?: number }) => {
        if (!generatedImage || isProcessing) return;
        setIsProcessing(true);
        setError('');
        setArrangedImage(null);
        setResizedImage(null);
        setActiveArrangement(null);
        try {
            const result = await resizeImage(generatedImage, options);
            setResizedImage(result);
        } catch (err) {
            setError(err instanceof Error ? err.message : 'Lỗi khi thay đổi kích thước ảnh.');
        } finally {
            setIsProcessing(false);
        }
    };

    const handleCustomArrangementChange = (size: string, count: number) => {
        setCustomArrangement(prev => ({
            ...prev,
            [size]: Math.max(0, count) // ensure non-negative
        }));
    };

    const handleCustomArrange = async () => {
        if (!generatedImage || isProcessing || Object.values(customArrangement).every(c => c === 0)) return;
        setIsProcessing(true);
        setActiveArrangement('custom');
        setError('');
        setArrangedImage(null);
        setResizedImage(null);
        try {
            const result = await arrangeCustomPhotosOnCanvas(generatedImage, paperSize, customArrangement);
            setArrangedImage(result);
        } catch (err) {
            setError(err instanceof Error ? err.message : 'Lỗi khi xếp ảnh tùy chọn.');
        } finally {
            setIsProcessing(false);
        }
    };

    const renderImagePanel = () => {
        if (!originalImage) {
            return html`
                <div class="image-panel-content">
                    <${PassportPhotoIcon} class="placeholder-icon"/>
                    <h4>Chào mừng tới Passport Photo AI</h4>
                    <p class="placeholder-text">Tải ảnh lên và chọn tùy chỉnh mong muốn để bắt đầu.</p>
                </div>
            `;
        }

        const imageToDisplay = resizedImage || arrangedImage || generatedImage;

        if (view === 'arrange_presets') {
            return html`
                ${lightboxImage && html`
                    <${SimpleLightbox}
                        imageUrl=${lightboxImage}
                        caption="Xem ảnh thẻ đã xếp"
                        onClose=${() => setLightboxImage(null)}
                    />
                `}
                ${isProcessing && html`<${Loader} text="Đang xử lý ảnh..." />`}
                <div class="image-display-wrapper" style=${{width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--background)'}}>
                    <img src=${imageToDisplay} alt="Processed Photo" style=${{cursor: 'pointer', maxWidth: '100%', maxHeight: '100%', objectFit: 'contain', border: '1px solid var(--border-color)', borderRadius: '4px'}} onClick=${() => setLightboxImage(imageToDisplay)} />
                </div>
                ${error && html`<div class="error-message">${error}</div>`}
            `;
        }
        
        // Default editor view
        return html`
            ${lightboxImage && html`
                <${SimpleLightbox}
                    imageUrl=${lightboxImage}
                    caption="Xem ảnh thẻ"
                    onClose=${() => setLightboxImage(null)}
                />
            `}
            ${generating && html`<${Loader} text="AI đang tạo ảnh thẻ của bạn..." />`}
            <div class="image-display-wrapper">
                <${ImageComparisonSlider} original=${originalImage} generated=${generatedImage} objectFit="contain" />
            </div>
            ${error && html`<div class="error-message">${error}</div>`}
            <div class="actions">
                 ${generatedImage && html`
                    <button class="btn btn-secondary" onClick=${() => setLightboxImage(generatedImage)}>
                        <${ViewIcon} /> Xem
                    </button>
                    <button class="btn btn-secondary" onClick=${handleCropAndArrange}>
                        Cắt & Xếp ảnh để in
                    </button>
                `}
                <${EnhancedDownloadButton} baseImageUrl=${generatedImage} filename="id-photo.jpeg">
                    <${DownloadIcon} /> Tải về
                </${EnhancedDownloadButton}>
            </div>
        `;
    };

    return html`
        <div class="editor-layout">
            ${view === 'editor' || !generatedImage ? html`
                <${IdPhotoSettingsPanel} 
                    settings=${settings} 
                    setSettings=${setSettings} 
                    onGenerate=${handleGenerate} 
                    generating=${generating} 
                    hasImage=${!!originalImage} 
                    originalImage=${originalImage}
                    onImageUpload=${handleImageUpload}
                />
            ` : html `
                 <${IdPhotoArrangePanel}
                    onQuickCropAndDownload=${handleQuickCropAndDownload}
                    onArrange=${handleArrange}
                    onDownloadArrangement=${handleDownloadFinalImage}
                    onBackToEditor=${handleBackToEditor}
                    activeArrangement=${activeArrangement}
                    isProcessing=${isProcessing}
                    canDownloadArrangement=${!!(arrangedImage || resizedImage)}
                    paperSize=${paperSize}
                    onPaperSizeChange=${handlePaperSizeChange}
                    onResize=${handleResize}
                    customWidth=${customWidth}
                    setCustomWidth=${setCustomWidth}
                    customHeight=${customHeight}
                    setCustomHeight=${setCustomHeight}
                    customArrangement=${customArrangement}
                    onCustomArrangementChange=${handleCustomArrangementChange}
                    onCustomArrange=${handleCustomArrange}
                />
            `}
            
            <div class="image-panel">
               ${renderImagePanel()}
            </div>
        </div>
    `;
};

const BatchIdPhotoEditor: FunctionalComponent = () => {
    const [images, setImages] = useState<ImageItem[]>([]);
    const [settings, setSettings] = useState<IdPhotoSettings>({
        gender: 'nu',
        ageGroup: 'thanh-nien',
        clothing: '', // Default to 'Giữ nguyên'
        customClothingImage: null,
        hairStyle: '', // Default to 'Giữ nguyên'
        background: 'xanh',
        beautifySkin: true,
        beautifyLevel: 50,
        brightnessLevel: 50,
        customPrompt: '',
    });
    const [processing, setProcessing] = useState(false);
    const [progress, setProgress] = useState(0);
    const [error, setError] = useState('');
    const [isDownloading, setIsDownloading] = useState(false);

    const handleFileChange = (e: TargetedEvent<HTMLInputElement>) => {
        if (!e.currentTarget.files) return;
        const files = Array.from(e.currentTarget.files);
        const newImages: ImageItem[] = files.map((file: File) => ({
            id: Date.now() + Math.random(),
            file: file,
            original: URL.createObjectURL(file),
            generated: null,
            status: 'pending'
        }));
        setImages(current => [...current, ...newImages]);
    };
    
    const readFileAsDataURL = (file: File): Promise<string> => {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result as string);
            reader.onerror = reject;
            reader.readAsDataURL(file);
        });
    }

    const processQueue = async (tasks: ImageItem[], concurrency: number, processFn: (task: ImageItem) => Promise<void>) => {
        let completed = 0;
        const queue = [...tasks];

        const worker = async () => {
            while(queue.length > 0) {
                const task = queue.shift();
                if (task) {
                    await processFn(task);
                    completed++;
                    setProgress(Math.round((completed / tasks.length) * 100));
                    if (queue.length > 0) {
                        await new Promise(resolve => setTimeout(resolve, 2000)); // Wait 2 seconds before the next call
                    }
                }
            }
        }
        
        const workers = Array(concurrency).fill(null).map(() => worker());
        await Promise.all(workers);
    };

    const handleBatchGenerate = async () => {
        setProcessing(true);
        setProgress(0);
        setError('');
        
        const tasks = images.filter(img => img.status === 'pending' || img.status === 'error');
        
        const processTask = async (img: ImageItem) => {
            setImages(current => current.map(i => i.id === img.id ? { ...i, status: 'processing' } : i));
            try {
                const originalDataUrl = await readFileAsDataURL(img.file);
                const result = await generateIdPhoto(originalDataUrl, settings);
                setImages(current => current.map(i => i.id === img.id ? { ...i, generated: result, status: 'done' } : i));
                const featureInfo = TABS.find(t => t.id === 'id-photo');
                await addHistoryItem({
                    original: originalDataUrl,
                    generated: result,
                    feature: 'id-photo',
                    featureLabel: featureInfo?.label || 'Ảnh Thẻ',
                });
            } catch (err) {
                 if (err instanceof Error) {
                    setError(err.message);
                } else {
                    setError(String(err));
                }
                setImages(current => current.map(i => i.id === img.id ? { ...i, status: 'error' } : i));
                // Stop the entire queue on first error
                throw err;
            }
        };
        
        try {
            await processQueue(tasks, 1, processTask);
        } catch (e) {
            console.error("Batch processing stopped due to an error.", e);
        } finally {
            setProcessing(false);
        }
    };
    
    const regenerateImage = async (id: number) => {
        const imageToRegen = images.find(i => i.id === id);
        if (!imageToRegen) return;

        setImages(current => current.map(i => i.id === id ? { ...i, status: 'processing' } : i));
        setError('');
        try {
            const originalDataUrl = await readFileAsDataURL(imageToRegen.file);
            const result = await generateIdPhoto(originalDataUrl, settings);
            setImages(current => current.map(i => i.id === id ? { ...i, generated: result, status: 'done' } : i));
            const featureInfo = TABS.find(t => t.id === 'id-photo');
            await addHistoryItem({
                original: originalDataUrl,
                generated: result,
                feature: 'id-photo',
                featureLabel: featureInfo?.label || 'Ảnh Thẻ',
            });
        } catch (err) {
             if (err instanceof Error) {
                setError(err.message);
            } else {
                setError(String(err));
            }
             setImages(current => current.map(i => i.id === id ? { ...i, status: 'error' } : i));
        }
    };
    
    const deleteImage = (id: number) => {
        setImages(current => current.filter(i => i.id !== id));
    }
    
    const handleDownloadAll = async () => {
        setIsDownloading(true);
        setError('');
        const imagesToDownload = images.filter(img => img.generated);

        for (let i = 0; i < imagesToDownload.length; i++) {
            const img = imagesToDownload[i];
            if (!img.generated) continue;
            
            // This re-uses the logic from EnhancedDownloadButton but in a loop.
            // For simplicity, we'll just trigger a standard download here.
            // A more advanced implementation could use JSZip to create a zip file.
            try {
                const link = document.createElement('a');
                link.href = img.generated;
                link.download = `id-photo-${img.id}.jpeg`;
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                await new Promise(resolve => setTimeout(resolve, 300)); // Small delay between downloads
            } catch(err) {
                 const message = `Lỗi khi tải ảnh ${i + 1}.`;
                setError(message);
                console.error(message, err);
                break;
            }
        }
        setIsDownloading(false);
    };
    
    const pendingCount = useMemo(() => images.filter(img => img.status === 'pending' || img.status === 'error').length, [images]);
    const buttonText = pendingCount > 0 ? `Tạo ${pendingCount} ảnh` : 'Tạo ảnh';

    return html`
        <div class="editor-layout">
            <${IdPhotoSettingsPanel}
                settings=${settings}
                setSettings=${setSettings}
                onGenerate=${handleBatchGenerate}
                generating=${processing}
                hasImage=${pendingCount > 0}
                buttonText=${buttonText}
                originalImage=${null}
                onImageUpload=${() => {}}
            />
            <div class="batch-panel">
                <div class="actions" style=${{ justifyContent: 'space-between', marginBottom: '1.5rem'}}>
                     <button class="btn btn-secondary" onClick=${() => document.getElementById('batch-file-input')?.click()}>
                         <${UploadIcon} /> Thêm ảnh
                    </button>
                     <input type="file" id="batch-file-input" multiple accept="image/*" style=${{display: 'none'}} onChange=${handleFileChange} />
                    <button class="btn btn-primary" onClick=${handleDownloadAll} disabled=${images.every(img => !img.generated) || isDownloading}>
                        ${isDownloading ? 'Đang tải...' : html`<${DownloadIcon} /> Tải tất cả`}
                    </button>
                </div>
                
                ${processing && html`
                    <div class="progress-bar">
                        <div class="progress-bar-inner" style=${{ width: `${progress}%` }}></div>
                        <span class="progress-label">${progress}%</span>
                    </div>
                `}
                
                ${error && html`<div class="error-message" style=${{marginTop: '1rem'}}>${error}</div>`}
    
                <div class="batch-grid">
                    ${images.map(img => html`
                        <div class="batch-item">
                            <div class="image-container">
                                <img src=${img.generated || img.original} />
                                ${img.status === 'processing' && html`<${Loader} text="Đang xử lý..." />`}
                                ${img.status === 'error' && html`<div class="error-badge">Lỗi</div>`}
                            </div>
                            <div class="batch-item-actions">
                                <button class="batch-item-btn" title="Tạo lại" onClick=${() => regenerateImage(img.id)}><${RegenerateIcon} /></button>
                                <button class="batch-item-btn" title="Xóa" onClick=${() => deleteImage(img.id)}><${DeleteIcon} /></button>
                            </div>
                        </div>
                    `)}
                     ${images.length === 0 && html`
                        <div class="image-panel-content" style=${{gridColumn: '1 / -1'}}>
                             <${PassportPhotoIcon} class="placeholder-icon"/>
                             <h4>Chỉnh sửa ảnh hàng loạt</h4>
                             <p class="placeholder-text">Tải nhiều ảnh lên để bắt đầu chỉnh sửa cùng lúc.</p>
                        </div>
                     `}
                </div>
            </div>
        </div>
    `;
};

export const IdPhotoApp: FunctionalComponent = () => {
    const [activeTab, setActiveTab] = useState('single');
    return html`
        <div>
            <div class="tabs">
                <button class="tab ${activeTab === 'single' ? 'active' : ''}" onClick=${() => setActiveTab('single')}>Chỉnh sửa một ảnh</button>
                <button class="tab ${activeTab === 'batch' ? 'active' : ''}" onClick=${() => setActiveTab('batch')}>Chỉnh sửa hàng loạt</button>
            </div>
            ${activeTab === 'single' ? html`<${IdPhotoEditor} />` : html`<${BatchIdPhotoEditor} />`}
        </div>
    `;
}