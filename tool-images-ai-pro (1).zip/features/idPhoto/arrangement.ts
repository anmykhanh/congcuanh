/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

const DPI = 300;

export const paperSizes: { [key: string]: { w: number; h: number } } = { // in mm
    '10x15cm': { w: 152, h: 102 },
    '13x18cm': { w: 178, h: 127 },
    'A4': { w: 297, h: 210 },
    'A5': { w: 210, h: 148 },
};

export const photoSizes: { [key: string]: { w: number; h: number } } = { // in mm
    '2x3cm': { w: 20, h: 30 },
    '3x4cm': { w: 30, h: 40 },
    '4x6cm': { w: 40, h: 60 },
};

const mmToPx = (mm: number) => (mm / 25.4) * DPI;

const loadImage = (src: string): Promise<HTMLImageElement> => new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => resolve(img);
    img.onerror = (e) => reject(e);
    img.src = src;
});

export const cropImage = (imageSrc: string, targetAspectRatio: number): Promise<string> => {
    return new Promise(async (resolve, reject) => {
        try {
            const img = await loadImage(imageSrc);
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            if (!ctx) return reject('Canvas context is not available');

            const sourceAspectRatio = img.width / img.height;
            let sx = 0, sy = 0, sWidth = img.width, sHeight = img.height;

            if (sourceAspectRatio > targetAspectRatio) {
                // source is wider than target, crop sides
                sWidth = img.height * targetAspectRatio;
                sx = (img.width - sWidth) / 2;
            } else if (sourceAspectRatio < targetAspectRatio) {
                // source is taller than target, crop top/bottom
                sHeight = img.width / targetAspectRatio;
                sy = (img.height - sHeight) / 2;
            }

            canvas.width = sWidth;
            canvas.height = sHeight;
            ctx.drawImage(img, sx, sy, sWidth, sHeight, 0, 0, sWidth, sHeight);
            resolve(canvas.toDataURL('image/jpeg'));

        } catch (error) {
            reject(error);
        }
    });
};

export const resizeImage = async (
    imageSrc: string,
    options: { aspectRatio?: number; width?: number; height?: number }
): Promise<string> => {
    const img = await loadImage(imageSrc);
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('Canvas context is not available');

    if (options.aspectRatio) {
        // This is a crop operation. The output size will be based on the source image.
        const sourceAspectRatio = img.width / img.height;
        let sx = 0, sy = 0, sWidth = img.width, sHeight = img.height;

        if (sourceAspectRatio > options.aspectRatio) { // Source is wider, crop sides
            sWidth = img.height * options.aspectRatio;
            sx = (img.width - sWidth) / 2;
        } else { // Source is taller, crop top/bottom
            sHeight = img.width / options.aspectRatio;
            sy = (img.height - sHeight) / 2;
        }
        canvas.width = sWidth;
        canvas.height = sHeight;
        ctx.drawImage(img, sx, sy, sWidth, sHeight, 0, 0, sWidth, sHeight);

    } else if (options.width && options.height) {
        // This is a resize & crop operation.
        const targetWidth = options.width;
        const targetHeight = options.height;
        canvas.width = targetWidth;
        canvas.height = targetHeight;

        const sourceAspectRatio = img.width / img.height;
        const targetAspectRatio = targetWidth / targetHeight;
        let sx = 0, sy = 0, sWidth = img.width, sHeight = img.height;

        if (sourceAspectRatio > targetAspectRatio) { // Source is wider, crop sides
            sWidth = img.height * targetAspectRatio;
            sx = (img.width - sWidth) / 2;
        } else { // Source is taller, crop top/bottom
            sHeight = img.width / targetAspectRatio;
            sy = (img.height - sHeight) / 2;
        }
        ctx.drawImage(img, sx, sy, sWidth, sHeight, 0, 0, targetWidth, targetHeight);

    } else {
        throw new Error('Invalid resize options. Provide either aspectRatio or both width and height.');
    }

    return canvas.toDataURL('image/jpeg', 0.95);
};

/**
 * Arranges a single photo onto a canvas based on paper and photo sizes.
 * @param imageSrc The source URL of the image to arrange.
 * @param paperSizeKey The key for the selected paper size (e.g., '10x15cm').
 * @param photoSizeKey The key for the selected photo size (e.g., '3x4cm').
 * @returns A Promise that resolves with the data URL of the canvas.
 */
export const arrangePhotosOnCanvas = (
    imageSrc: string,
    paperSizeKey: string,
    photoSizeKey: string
): Promise<string> => {
    return new Promise((resolve, reject) => {
        const paperDim = paperSizes[paperSizeKey];
        const photoDim = photoSizes[photoSizeKey];
        if (!paperDim || !photoDim) {
            return reject(new Error('Khổ giấy hoặc kích thước ảnh không hợp lệ'));
        }

        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        if (!ctx) return reject(new Error('Không thể tạo canvas context'));

        const paperWidthPx = mmToPx(paperDim.w);
        const paperHeightPx = mmToPx(paperDim.h);
        const photoWidthPx = mmToPx(photoDim.w);
        const photoHeightPx = mmToPx(photoDim.h);
        
        canvas.width = paperWidthPx;
        canvas.height = paperHeightPx;
        ctx.fillStyle = 'white';
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        const img = new Image();
        img.crossOrigin = "anonymous";
        img.onload = () => {
            const padding = mmToPx(2); // 2mm padding between photos

            const cols = Math.floor((paperWidthPx + padding) / (photoWidthPx + padding));
            const rows = Math.floor((paperHeightPx + padding) / (photoHeightPx + padding));
            
            // Center the grid of photos on the paper
            const gridWidth = cols * photoWidthPx + (cols - 1) * padding;
            const gridHeight = rows * photoHeightPx + (rows - 1) * padding;
            const offsetX = (paperWidthPx - gridWidth) / 2;
            const offsetY = (paperHeightPx - gridHeight) / 2;

            for (let r = 0; r < rows; r++) {
                for (let c = 0; c < cols; c++) {
                    const x = offsetX + c * (photoWidthPx + padding);
                    const y = offsetY + r * (photoHeightPx + padding);
                    
                    // Cropping logic (center crop the source image to fit the target photo size)
                    const sourceAspectRatio = img.width / img.height;
                    const targetAspectRatio = photoWidthPx / photoHeightPx;
                    let sWidth, sHeight, sx, sy;

                    if (sourceAspectRatio > targetAspectRatio) { // Source image is wider, crop sides
                        sHeight = img.height;
                        sWidth = sHeight * targetAspectRatio;
                        sx = (img.width - sWidth) / 2;
                        sy = 0;
                    } else { // Source image is taller or same aspect ratio, crop top/bottom
                        sWidth = img.width;
                        sHeight = sWidth / targetAspectRatio;
                        sx = 0;
                        sy = (img.height - sHeight) / 2;
                    }

                    ctx.drawImage(img, sx, sy, sWidth, sHeight, x, y, photoWidthPx, photoHeightPx);
                }
            }
            resolve(canvas.toDataURL('image/jpeg'));
        };
        img.onerror = () => reject(new Error('Không thể tải ảnh để xếp'));
        img.src = imageSrc;
    });
};

export const arrangeMixedLayout = async (imageSrc: string): Promise<string> => {
    const paperDim = paperSizes['10x15cm'];
    const photo4x6Dim = photoSizes['4x6cm'];
    const photo3x4Dim = photoSizes['3x4cm'];
    
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('Canvas context is not available');

    const paperWidthPx = mmToPx(paperDim.w);
    const paperHeightPx = mmToPx(paperDim.h);

    canvas.width = paperWidthPx;
    canvas.height = paperHeightPx;
    ctx.fillStyle = 'white';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    const [img4x6, img3x4] = await Promise.all([
        loadImage(imageSrc),
        loadImage(imageSrc)
    ]);
    
    const padding = mmToPx(2);
    
    // Top row: 3 x (4x6 photos)
    const photo4x6W = mmToPx(photo4x6Dim.w);
    const photo4x6H = mmToPx(photo4x6Dim.h);
    const topRowWidth = 3 * photo4x6W + 2 * padding;
    const topOffsetX = (paperWidthPx - topRowWidth) / 2;
    const topOffsetY = padding * 2; // Extra padding from top

    for (let i = 0; i < 3; i++) {
        const sAR = img4x6.width / img4x6.height;
        const tAR = photo4x6W / photo4x6H;
        let sW = img4x6.width, sH = img4x6.height, sx = 0, sy = 0;
        if (sAR > tAR) { sW = sH * tAR; sx = (img4x6.width - sW) / 2; } 
        else { sH = sW / tAR; sy = (img4x6.height - sH) / 2; }
        ctx.drawImage(img4x6, sx, sy, sW, sH, topOffsetX + i * (photo4x6W + padding), topOffsetY, photo4x6W, photo4x6H);
    }
    
    // Bottom row: 4 x (3x4 photos)
    const photo3x4W = mmToPx(photo3x4Dim.w);
    const photo3x4H = mmToPx(photo3x4Dim.h);
    const bottomRowWidth = 4 * photo3x4W + 3 * padding;
    const bottomOffsetX = (paperWidthPx - bottomRowWidth) / 2;
    const bottomOffsetY = topOffsetY + photo4x6H + padding;

    for (let i = 0; i < 4; i++) {
        const sAR = img3x4.width / img3x4.height;
        const tAR = photo3x4W / photo3x4H;
        let sW = img3x4.width, sH = img3x4.height, sx = 0, sy = 0;
        if (sAR > tAR) { sW = sH * tAR; sx = (img3x4.width - sW) / 2; }
        else { sH = sW / tAR; sy = (img3x4.height - sH) / 2; }
        ctx.drawImage(img3x4, sx, sy, sW, sH, bottomOffsetX + i * (photo3x4W + padding), bottomOffsetY, photo3x4W, photo3x4H);
    }

    return canvas.toDataURL('image/jpeg');
};

export const arrangeCustomPhotosOnCanvas = async (
    imageSrc: string,
    paperSizeKey: string,
    photoQuantities: { [photoSizeKey: string]: number }
): Promise<string> => {
    const paperDim = paperSizes[paperSizeKey];
    if (!paperDim) {
        throw new Error('Khổ giấy không hợp lệ');
    }

    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('Không thể tạo canvas context');

    const paperWidthPx = mmToPx(paperDim.w);
    const paperHeightPx = mmToPx(paperDim.h);

    canvas.width = paperWidthPx;
    canvas.height = paperHeightPx;
    ctx.fillStyle = 'white';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    const img = await loadImage(imageSrc);
    const padding = mmToPx(2);

    // Create a list of all photo instances to be placed
    const photosToPlace = [];
    for (const sizeKey in photoQuantities) {
        const quantity = photoQuantities[sizeKey];
        const photoDim = photoSizes[sizeKey];
        if (quantity > 0 && photoDim) {
            for (let i = 0; i < quantity; i++) {
                photosToPlace.push({
                    w: mmToPx(photoDim.w),
                    h: mmToPx(photoDim.h)
                });
            }
        }
    }
    
    // Sort photos by height (descending) to make packing simpler
    photosToPlace.sort((a, b) => b.h - a.h);

    let currentX = padding;
    let currentY = padding;
    let rowMaxHeight = 0;

    for (const photo of photosToPlace) {
        if (currentX + photo.w > paperWidthPx - padding) {
            // Move to next row
            currentX = padding;
            currentY += rowMaxHeight + padding;
            rowMaxHeight = 0;
        }

        if (currentY + photo.h > paperHeightPx - padding) {
            // Not enough space on the paper
            const photosPlaced = photosToPlace.indexOf(photo);
            throw new Error(`Không đủ chỗ! Chỉ xếp được ${photosPlaced}/${photosToPlace.length} ảnh.`);
        }

        // Draw image (with cropping)
        const sourceAspectRatio = img.width / img.height;
        const targetAspectRatio = photo.w / photo.h;
        let sWidth, sHeight, sx, sy;

        if (sourceAspectRatio > targetAspectRatio) {
            sHeight = img.height;
            sWidth = sHeight * targetAspectRatio;
            sx = (img.width - sWidth) / 2;
            sy = 0;
        } else {
            sWidth = img.width;
            sHeight = sWidth / targetAspectRatio;
            sx = 0;
            sy = (img.height - sHeight) / 2;
        }

        ctx.drawImage(img, sx, sy, sWidth, sHeight, currentX, currentY, photo.w, photo.h);

        // Update position for next photo
        currentX += photo.w + padding;
        if (photo.h > rowMaxHeight) {
            rowMaxHeight = photo.h;
        }
    }

    return canvas.toDataURL('image/jpeg');
};